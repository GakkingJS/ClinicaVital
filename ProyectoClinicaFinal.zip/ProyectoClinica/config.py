"""
Configuración de la aplicación
"""

class Config:
    """Configuración base"""
    SECRET_KEY = 'tu_clave_secreta_super_segura_aqui_2024'
    
    # MySQL
    MYSQL_HOST = 'localhost'
    MYSQL_USER = 'root'
    MYSQL_PASSWORD = ''
    MYSQL_DB = 'clinica_vital'
    
    # Sesiones
    SESSION_COOKIE_SECURE = False  # True en producción con HTTPS
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    
    # Uploads (si necesitas subir archivos)
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 MB max

class DevelopmentConfig(Config):
    """Configuración para desarrollo"""
    DEBUG = True

class ProductionConfig(Config):
    """Configuración para producción"""
    DEBUG = False
    SESSION_COOKIE_SECURE = True