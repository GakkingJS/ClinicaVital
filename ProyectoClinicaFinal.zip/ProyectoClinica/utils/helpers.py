from flask import request, g
import secrets
import string


def registrar_auditoria(usuario_id, accion, modulo, registro_id=None, detalles=None):
    """Registra acciones en la tabla de auditoría general"""
    try:
        cursor = g.mysql.connection.cursor()
        ip = request.remote_addr
        
        query = """
            INSERT INTO auditoria (usuario_id, accion, modulo, registro_id, detalles, ip_address)
            VALUES (%s, %s, %s, %s, %s, %s)
        """
        cursor.execute(query, (usuario_id, accion, modulo, registro_id, detalles, ip))
        g.mysql.connection.commit()
        cursor.close()
        
    except Exception as e:
        print(f"Error al registrar auditoría: {str(e)}")


def registrar_auditoria_historia(historia_id, paciente_id, doctor_id, usuario_id, 
                                accion, descripcion, campo_modificado=None, 
                                valor_anterior=None, valor_nuevo=None):
    """
    Registra auditoría específica de historias clínicas
    """
    try:
        cursor = g.mysql.connection.cursor()
        ip_address = request.remote_addr if request else None
        
        query = """
            INSERT INTO auditoria_historias 
            (historia_id, paciente_id, doctor_id, usuario_id, accion, tabla, 
             campo_modificado, valor_anterior, valor_nuevo, descripcion, ip_address)
            VALUES (%s, %s, %s, %s, %s, 'historias_clinicas', %s, %s, %s, %s, %s)
        """
        
        cursor.execute(query, (
            historia_id, 
            paciente_id, 
            doctor_id, 
            usuario_id, 
            accion,
            campo_modificado,
            valor_anterior,
            valor_nuevo,
            descripcion,
            ip_address
        ))
        
        g.mysql.connection.commit()
        cursor.close()
        
    except Exception as e:
        print(f"Error al registrar auditoría de historia: {str(e)}")


def generar_password_temporal(longitud=12):
    """Genera una contraseña temporal segura"""
    caracteres = string.ascii_letters + string.digits + "!@#$%"
    password = ''.join(secrets.choice(caracteres) for _ in range(longitud))
    return password
