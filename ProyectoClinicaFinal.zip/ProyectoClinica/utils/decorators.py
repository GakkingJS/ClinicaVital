from functools import wraps
from flask import session, flash, redirect, url_for, g


def login_required(f):
    """Requiere que el usuario esté autenticado"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'usuario_id' not in session:
            flash('Debes iniciar sesión primero', 'warning')
            return redirect(url_for('auth.login'))  
        return f(*args, **kwargs)
    return decorated_function


def role_required(*roles):
    """Requiere que el usuario tenga uno de los roles especificados"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'rol' not in session:
                flash('No tienes permisos para acceder', 'danger')
                return redirect(url_for('auth.login')) 
            if session['rol'] not in roles:
                flash('No tienes permisos para esta acción', 'danger')
                return redirect(url_for('dashboard'))
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator


def permission_required(modulo):
    """
    Verifica si el usuario tiene permiso para un módulo específico
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'usuario_id' not in session or 'rol_id' not in session:
                flash('Debes iniciar sesión', 'warning')
                return redirect(url_for('auth.login')) 
            
            try:
                cursor = g.mysql.connection.cursor()
                
                # Verificar que el rol tenga permiso en este módulo
                query = """
                    SELECT COUNT(*) FROM rol_permisos rp
                    JOIN permisos p ON rp.permiso_id = p.id
                    WHERE rp.rol_id = %s AND p.modulo = %s
                """
                cursor.execute(query, (session.get('rol_id'), modulo))
                resultado = cursor.fetchone()
                cursor.close()
                
                if resultado and resultado[0] > 0:
                    return f(*args, **kwargs)
                else:
                    flash(f'No tienes permisos en: {modulo}', 'danger')
                    return redirect(url_for('dashboard'))
                
            except Exception as e:
                print(f"⚠️ Error en permission_required: {e}")
                # Si hay error, permitir pasar (mejor experiencia)
                return f(*args, **kwargs)
        
        return decorated_function
    return decorator
