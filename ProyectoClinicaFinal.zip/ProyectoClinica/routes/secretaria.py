from flask import Blueprint, render_template, request, redirect, url_for, flash, session, g
from utils.decorators import login_required, role_required, permission_required
from utils.helpers import registrar_auditoria
from werkzeug.security import generate_password_hash
import secrets

secretaria_bp = Blueprint('secretaria', __name__, template_folder='templates')


# =====================================
# DASHBOARD
# =====================================
@secretaria_bp.route('/dashboard')
@login_required
@role_required('secretaria')
def dashboard():
    """Dashboard principal - Muestra citas de hoy"""
    cursor = g.mysql.connection.cursor()
    
    try:
        query = """
            SELECT c.*, 
                   up.nombre_completo as paciente_nombre,
                   ud.nombre_completo as doctor_nombre,
                   e.nombre as especialidad
            FROM citas c
            JOIN pacientes p ON c.paciente_id = p.id
            JOIN usuarios up ON p.usuario_id = up.id
            JOIN doctores d ON c.doctor_id = d.id
            JOIN usuarios ud ON d.usuario_id = ud.id
            JOIN especialidades e ON d.especialidad_id = e.id
            WHERE DATE(c.fecha_hora) = CURDATE()
            ORDER BY c.fecha_hora
        """
        cursor.execute(query)
        citas_hoy = cursor.fetchall()
        
        return render_template('secretaria/dashboard.html', citas_hoy=citas_hoy)
        
    except Exception as e:
        flash(f'Error al cargar dashboard: {str(e)}', 'danger')
        return redirect(url_for('secretaria.dashboard'))
    finally:
        cursor.close()


# =====================================
# CITAS
# =====================================
@secretaria_bp.route('/cita/crear', methods=['GET', 'POST'])
@login_required
@role_required('secretaria')
def crear_cita():
    """Crear nueva cita médica"""
    if request.method == 'POST':
        cursor = g.mysql.connection.cursor()
        
        try:
            paciente_id = request.form.get('paciente_id')
            doctor_id = request.form.get('doctor_id')
            fecha_hora = request.form.get('fecha_hora')
            motivo = request.form.get('motivo', '')
            
            if not all([paciente_id, doctor_id, fecha_hora]):
                flash('Por favor completa todos los campos requeridos', 'warning')
                return redirect(url_for('secretaria.crear_cita'))
            
            query = """
                INSERT INTO citas 
                (paciente_id, doctor_id, fecha_hora, motivo, estado, creada_por)
                VALUES (%s, %s, %s, %s, 'programada', %s)
            """
            cursor.execute(query, (paciente_id, doctor_id, fecha_hora, motivo, session['usuario_id']))
            cita_id = cursor.lastrowid
            
            g.mysql.connection.commit()
            
            registrar_auditoria(session['usuario_id'], 'crear_cita', 'citas', cita_id)
            flash('✅ Cita agendada exitosamente', 'success')
            return redirect(url_for('secretaria.ver_todas_citas'))
            
        except Exception as e:
            g.mysql.connection.rollback()
            flash(f'❌ Error al crear cita: {str(e)}', 'danger')
            return redirect(url_for('secretaria.crear_cita'))
        finally:
            cursor.close()
    
    # GET - Obtener doctores y pacientes
    cursor = g.mysql.connection.cursor()
    
    try:
        cursor.execute("""
            SELECT d.id, u.nombre_completo, e.nombre as especialidad 
            FROM doctores d 
            JOIN usuarios u ON d.usuario_id = u.id 
            JOIN especialidades e ON d.especialidad_id = e.id
            WHERE u.activo = TRUE
            ORDER BY u.nombre_completo
        """)
        doctores = cursor.fetchall()
        
        cursor.execute("""
            SELECT p.id, u.nombre_completo, u.cedula
            FROM pacientes p 
            JOIN usuarios u ON p.usuario_id = u.id
            WHERE u.activo = TRUE
            ORDER BY u.nombre_completo
        """)
        pacientes = cursor.fetchall()
        
        return render_template('secretaria/crear_cita.html', doctores=doctores, pacientes=pacientes)
        
    except Exception as e:
        flash(f'❌ Error al cargar datos: {str(e)}', 'danger')
        return redirect(url_for('secretaria.dashboard'))
    finally:
        cursor.close()


@secretaria_bp.route('/citas')
@login_required
@role_required('secretaria')
def ver_todas_citas():
    """Ver todas las citas futuras"""
    cursor = g.mysql.connection.cursor()
    
    try:
        query = """
            SELECT c.*, 
                   up.nombre_completo as paciente_nombre,
                   ud.nombre_completo as doctor_nombre,
                   e.nombre as especialidad
            FROM citas c
            JOIN pacientes p ON c.paciente_id = p.id
            JOIN usuarios up ON p.usuario_id = up.id
            JOIN doctores d ON c.doctor_id = d.id
            JOIN usuarios ud ON d.usuario_id = ud.id
            JOIN especialidades e ON d.especialidad_id = e.id
            WHERE c.fecha_hora >= NOW()
            ORDER BY c.fecha_hora
            LIMIT 100
        """
        cursor.execute(query)
        citas = cursor.fetchall()
        
        return render_template('secretaria/citas.html', citas=citas)
        
    except Exception as e:
        flash(f'❌ Error al cargar citas: {str(e)}', 'danger')
        return redirect(url_for('secretaria.dashboard'))
    finally:
        cursor.close()


@secretaria_bp.route('/cita/<int:cita_id>/cancelar', methods=['POST'])
@login_required
@role_required('secretaria')
def cancelar_cita(cita_id):
    """Cancelar una cita médica"""
    cursor = g.mysql.connection.cursor()
    
    try:
        cursor.execute("UPDATE citas SET estado = 'cancelada' WHERE id = %s", (cita_id,))
        g.mysql.connection.commit()
        
        registrar_auditoria(session['usuario_id'], 'cancelar_cita', 'citas', cita_id)
        flash('✅ Cita cancelada exitosamente', 'success')
        
    except Exception as e:
        g.mysql.connection.rollback()
        flash(f'❌ Error al cancelar cita: {str(e)}', 'danger')
    finally:
        cursor.close()
    
    return redirect(url_for('secretaria.ver_todas_citas'))


# =====================================
# PACIENTES
# =====================================
@secretaria_bp.route('/pacientes')
@login_required
@role_required('secretaria')
def ver_pacientes():
    """Ver lista de todos los pacientes"""
    cursor = g.mysql.connection.cursor()
    
    try:
        query = """
            SELECT p.id, u.nombre_completo, u.cedula, u.email, u.telefono, 
                   u.activo, p.tipo_sangre
            FROM pacientes p
            JOIN usuarios u ON p.usuario_id = u.id
            ORDER BY u.nombre_completo ASC
        """
        cursor.execute(query)
        pacientes = cursor.fetchall()
        
        return render_template('secretaria/pacientes.html', pacientes=pacientes)
        
    except Exception as e:
        flash(f'❌ Error al cargar pacientes: {str(e)}', 'danger')
        return redirect(url_for('secretaria.dashboard'))
    finally:
        cursor.close()


@secretaria_bp.route('/paciente/registrar', methods=['GET', 'POST'])
@login_required
@role_required('secretaria')
def registrar_paciente():
    """Registrar nuevo paciente en el sistema"""
    if request.method == 'POST':
        nombre = request.form.get('nombre_completo')
        cedula = request.form.get('cedula')
        email = request.form.get('email')
        telefono = request.form.get('telefono', '')
        tipo_sangre = request.form.get('tipo_sangre', '')
        fecha_nacimiento = request.form.get('fecha_nacimiento', None)
        genero = request.form.get('genero', None)
        
        cursor = g.mysql.connection.cursor()
        
        try:
            # Validar que todos los campos requeridos estén completos
            if not all([nombre, cedula, email]):
                flash('❌ Por favor completa todos los campos requeridos', 'warning')
                return redirect(url_for('secretaria.registrar_paciente'))
            
            # Verificar que cedula y email no existan
            cursor.execute("SELECT id FROM usuarios WHERE cedula = %s OR email = %s", (cedula, email))
            if cursor.fetchone():
                flash('❌ La cédula o email ya están registrados', 'danger')
                return redirect(url_for('secretaria.registrar_paciente'))
            
            # Generar contraseña temporal
            password_temporal = cedula
            password_hash = generate_password_hash(password_temporal)
            
            # Insertar el usuario con rol_id = 3 (PACIENTE) 
            cursor.execute("""
                INSERT INTO usuarios (nombre_completo, cedula, telefono, email, username, 
                                    password, fecha_nacimiento, genero, rol_id, activo)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, 4, TRUE)
            """, (nombre, cedula, telefono, email, cedula, password_hash, fecha_nacimiento, genero))
            
            usuario_id = cursor.lastrowid
            
            # Insertar el paciente vinculado al usuario
            cursor.execute("""
                INSERT INTO pacientes (usuario_id, tipo_sangre)
                VALUES (%s, %s)
            """, (usuario_id, tipo_sangre))
            
            g.mysql.connection.commit()
            
            registrar_auditoria(session['usuario_id'], 'registrar_paciente', 'pacientes', usuario_id)
            flash(f'✅ Paciente registrado exitosamente. Contraseña temporal: {password_temporal}', 'success')
            return redirect(url_for('secretaria.ver_pacientes'))
            
        except Exception as e:
            g.mysql.connection.rollback()
            flash(f'❌ Error al registrar paciente: {str(e)}', 'danger')
            return redirect(url_for('secretaria.registrar_paciente'))
        finally:
            cursor.close()
    
    return render_template('secretaria/registrar_paciente.html')


@secretaria_bp.route('/paciente/<int:paciente_id>')
@login_required
@role_required('secretaria')
def ver_paciente(paciente_id):
    """Ver perfil detallado de un paciente"""
    cursor = g.mysql.connection.cursor()
    
    try:
        # Información del paciente
        query_paciente = """
            SELECT p.id, p.usuario_id, p.tipo_sangre, p.alergias, 
                   p.enfermedades_cronicas, p.contacto_emergencia, 
                   p.telefono_emergencia,
                   u.nombre_completo, u.cedula, u.email, u.telefono,
                   u.fecha_nacimiento, u.genero, u.direccion
            FROM pacientes p
            JOIN usuarios u ON p.usuario_id = u.id
            WHERE p.id = %s
        """
        cursor.execute(query_paciente, (paciente_id,))
        paciente = cursor.fetchone()
        
        if not paciente:
            flash('❌ Paciente no encontrado', 'danger')
            return redirect(url_for('secretaria.ver_pacientes'))
        
        # Últimas 5 historias clínicas
        cursor.execute("""
            SELECT hc.*, ud.nombre_completo as doctor_nombre
            FROM historias_clinicas hc
            JOIN doctores d ON hc.doctor_id = d.id
            JOIN usuarios ud ON d.usuario_id = ud.id
            WHERE hc.paciente_id = %s
            ORDER BY hc.fecha_consulta DESC
            LIMIT 5
        """, (paciente_id,))
        historias = cursor.fetchall()
        
        # Últimas 5 citas
        cursor.execute("""
            SELECT c.*, ud.nombre_completo as doctor_nombre
            FROM citas c
            JOIN doctores d ON c.doctor_id = d.id
            JOIN usuarios ud ON d.usuario_id = ud.id
            WHERE c.paciente_id = %s
            ORDER BY c.fecha_hora DESC
            LIMIT 5
        """, (paciente_id,))
        citas = cursor.fetchall()
        
        return render_template('secretaria/ver_paciente.html', 
                             paciente=paciente, 
                             historias=historias,
                             citas=citas)
    except Exception as e:
        flash(f'❌ Error al cargar información del paciente: {str(e)}', 'danger')
        return redirect(url_for('secretaria.ver_pacientes'))
    finally:
        cursor.close()


# =====================================
# HISTORIAS CLÍNICAS
# =====================================
@secretaria_bp.route('/historias-clinicas')
@login_required
@role_required('secretaria')
def listar_historias_clinicas():
    """Ver TODAS las historias clínicas de todos los pacientes"""
    cursor = g.mysql.connection.cursor()
    
    try:
        query = """
            SELECT hc.*, 
                   up.nombre_completo as paciente_nombre, up.cedula,
                   ud.nombre_completo as doctor_nombre, e.nombre as especialidad
            FROM historias_clinicas hc
            JOIN pacientes p ON hc.paciente_id = p.id
            JOIN usuarios up ON p.usuario_id = up.id
            JOIN doctores d ON hc.doctor_id = d.id
            JOIN usuarios ud ON d.usuario_id = ud.id
            JOIN especialidades e ON d.especialidad_id = e.id
            ORDER BY hc.fecha_consulta DESC
        """
        cursor.execute(query)
        historias = cursor.fetchall()
        
        return render_template('secretaria/historias_clinicas.html', historias=historias)
        
    except Exception as e:
        flash(f'❌ Error al cargar historias clínicas: {str(e)}', 'danger')
        return redirect(url_for('secretaria.dashboard'))
    finally:
        cursor.close()


@secretaria_bp.route('/paciente/<int:paciente_id>/historias-clinicas')
@login_required
@role_required('secretaria')
def ver_historias_paciente(paciente_id):
    """Ver TODAS las historias clínicas de UN paciente específico"""
    cursor = g.mysql.connection.cursor()
    
    try:
        # Verificar que el paciente existe
        cursor.execute("SELECT id, usuario_id FROM pacientes WHERE id = %s", (paciente_id,))
        paciente_check = cursor.fetchone()
        
        if not paciente_check:
            flash('❌ Paciente no encontrado', 'danger')
            return redirect(url_for('secretaria.ver_pacientes'))
        
        # Obtener datos del paciente
        cursor.execute("""
            SELECT p.id, u.nombre_completo, u.cedula, u.email
            FROM pacientes p
            JOIN usuarios u ON p.usuario_id = u.id
            WHERE p.id = %s
        """, (paciente_id,))
        paciente = cursor.fetchone()
        
        # Obtener todas las historias clínicas del paciente
        cursor.execute("""
            SELECT hc.*, ud.nombre_completo as doctor_nombre, e.nombre as especialidad
            FROM historias_clinicas hc
            JOIN doctores d ON hc.doctor_id = d.id
            JOIN usuarios ud ON d.usuario_id = ud.id
            JOIN especialidades e ON d.especialidad_id = e.id
            WHERE hc.paciente_id = %s
            ORDER BY hc.fecha_consulta DESC
        """, (paciente_id,))
        historias = cursor.fetchall()
        
        return render_template('secretaria/historias_paciente.html', 
                             paciente=paciente, 
                             historias=historias)
        
    except Exception as e:
        flash(f'❌ Error al cargar historias clínicas: {str(e)}', 'danger')
        return redirect(url_for('secretaria.ver_pacientes'))
    finally:
        cursor.close()


@secretaria_bp.route('/historia/<int:historia_id>')
@login_required
@role_required('secretaria')
def ver_historia(historia_id):
    """Ver detalle completo de una historia clínica"""
    cursor = g.mysql.connection.cursor()
    
    try:
        query = """
            SELECT hc.*, 
                   p.tipo_sangre, p.alergias, p.enfermedades_cronicas,
                   up.nombre_completo as paciente_nombre, up.cedula, up.email, up.telefono,
                   ud.nombre_completo as doctor_nombre, e.nombre as especialidad
            FROM historias_clinicas hc
            JOIN pacientes p ON hc.paciente_id = p.id
            JOIN usuarios up ON p.usuario_id = up.id
            JOIN doctores d ON hc.doctor_id = d.id
            JOIN usuarios ud ON d.usuario_id = ud.id
            JOIN especialidades e ON d.especialidad_id = e.id
            WHERE hc.id = %s
        """
        cursor.execute(query, (historia_id,))
        historia = cursor.fetchone()
        
        if not historia:
            flash('❌ Historia clínica no encontrada', 'danger')
            return redirect(url_for('secretaria.ver_pacientes'))
        
        return render_template('secretaria/ver_historia.html', historia=historia)
        
    except Exception as e:
        flash(f'❌ Error al cargar historia clínica: {str(e)}', 'danger')
        return redirect(url_for('secretaria.ver_pacientes'))
    finally:
        cursor.close()


# =====================================
# REPORTES
# =====================================
@secretaria_bp.route('/reportes')
@login_required
@role_required('secretaria')
def reportes():
    """Ver reportes y estadísticas"""
    cursor = g.mysql.connection.cursor()

    try:
        # Total de pacientes
        cursor.execute("SELECT COUNT(*) FROM pacientes")
        total_pacientes = cursor.fetchone()[0]

        # Total de citas
        cursor.execute("SELECT COUNT(*) FROM citas")
        total_citas = cursor.fetchone()[0]

        # Citas este mes
        cursor.execute("""
            SELECT COUNT(*) FROM citas 
            WHERE MONTH(fecha_hora) = MONTH(CURDATE()) 
            AND YEAR(fecha_hora) = YEAR(CURDATE())
        """)
        citas_mes = cursor.fetchone()[0]

        # Pacientes atendidos
        cursor.execute("SELECT COUNT(*) FROM citas WHERE estado = 'completada'")
        pacientes_atendidos = cursor.fetchone()[0]

        # Citas mensuales (últimos 6 meses)
        cursor.execute("""
            SELECT DATE_FORMAT(fecha_hora, '%Y-%m') as mes, COUNT(*) as total
            FROM citas 
            WHERE fecha_hora >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
            GROUP BY DATE_FORMAT(fecha_hora, '%Y-%m')
            ORDER BY mes
        """)
        citas_mensuales = cursor.fetchall()

        return render_template(
            'secretaria/reportes.html',
            total_pacientes=total_pacientes,
            total_citas=total_citas,
            citas_mes=citas_mes,
            pacientes_atendidos=pacientes_atendidos,
            citas_mensuales=citas_mensuales
        )
        
    except Exception as e:
        flash(f'❌ Error al cargar reportes: {str(e)}', 'danger')
        return redirect(url_for('secretaria.dashboard'))
    finally:
        cursor.close()