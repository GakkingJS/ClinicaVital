from flask import Blueprint, render_template, request, redirect, url_for, session, g, flash, jsonify, make_response
from utils.decorators import login_required, role_required
from utils.helpers import registrar_auditoria
from datetime import datetime, date
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from io import BytesIO
import os
from werkzeug.utils import secure_filename

doctor_bp = Blueprint('doctor', __name__)

# =====================================
# CONFIGURACIÓN DE UPLOADS
# =====================================
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


# =====================================
# DASHBOARD
# =====================================
@doctor_bp.route('/dashboard')
@login_required
@role_required('doctor')
def dashboard():
    """Dashboard principal del doctor"""
    cursor = g.mysql.connection.cursor()
    
    try:
        cursor.execute("SELECT id FROM doctores WHERE usuario_id = %s", (session['usuario_id'],))
        doctor = cursor.fetchone()
        
        if not doctor:
            flash('No se encontró información del doctor', 'danger')
            return redirect(url_for('auth.login'))
        
        doctor_id = doctor[0]
        
        query_citas = """
            SELECT c.*, u.nombre_completo, u.cedula
            FROM citas c
            JOIN pacientes p ON c.paciente_id = p.id
            JOIN usuarios u ON p.usuario_id = u.id
            WHERE c.doctor_id = %s AND DATE(c.fecha_hora) = CURDATE()
            ORDER BY c.fecha_hora ASC
        """
        cursor.execute(query_citas, (doctor_id,))
        citas_hoy = cursor.fetchall()
        
        query_historias = """
            SELECT COUNT(*) FROM historias_clinicas
            WHERE doctor_id = %s AND MONTH(fecha_consulta) = MONTH(NOW()) AND YEAR(fecha_consulta) = YEAR(NOW())
        """
        cursor.execute(query_historias, (doctor_id,))
        historias_mes = cursor.fetchone()[0]
        
        query_pacientes = """
            SELECT COUNT(DISTINCT hc.paciente_id) FROM historias_clinicas hc
            WHERE hc.doctor_id = %s AND MONTH(hc.fecha_consulta) = MONTH(NOW()) AND YEAR(hc.fecha_consulta) = YEAR(NOW())
        """
        cursor.execute(query_pacientes, (doctor_id,))
        pacientes_mes = cursor.fetchone()[0]
        
        query_recetas = """
            SELECT COUNT(*) FROM recetas
            WHERE doctor_id = %s AND activa = TRUE
        """
        cursor.execute(query_recetas, (doctor_id,))
        recetas_activas = cursor.fetchone()[0]
        
        return render_template('doctor/dashboard.html', 
                             citas_hoy=citas_hoy,
                             historias_mes=historias_mes,
                             pacientes_mes=pacientes_mes,
                             recetas_activas=recetas_activas)
        
    except Exception as e:
        flash(f'Error al cargar el dashboard: {str(e)}', 'danger')
        return redirect(url_for('auth.login'))
    finally:
        cursor.close()


# =====================================
# CITAS
# =====================================
@doctor_bp.route('/nueva-cita', methods=['GET', 'POST'])
@login_required
@role_required('doctor')
def nueva_cita():
    """Crear nueva cita"""
    cursor = g.mysql.connection.cursor()
    
    try:
        cursor.execute("SELECT id FROM doctores WHERE usuario_id = %s", (session['usuario_id'],))
        doctor = cursor.fetchone()
        doctor_id = doctor[0]
        
        if request.method == 'POST':
            paciente_id = request.form.get('paciente_id')
            fecha = request.form.get('fecha')
            hora = request.form.get('hora')
            motivo = request.form.get('motivo')
            notas = request.form.get('notas')
            
            fecha_hora = f"{fecha} {hora}"
            
            cursor.execute("""
                INSERT INTO citas (paciente_id, doctor_id, fecha_hora, motivo, notas, estado)
                VALUES (%s, %s, %s, %s, %s, 'programada')
            """, (paciente_id, doctor_id, fecha_hora, motivo, notas))
            
            g.mysql.connection.commit()
            registrar_auditoria(session['usuario_id'], 'crear_cita', 'citas', paciente_id)
            flash('Cita creada exitosamente', 'success')
            return redirect(url_for('doctor.dashboard'))
        
        cursor.execute("""
            SELECT p.id, u.nombre_completo, u.cedula, u.telefono
            FROM pacientes p
            JOIN usuarios u ON p.usuario_id = u.id
            WHERE u.activo = TRUE
            ORDER BY u.nombre_completo
        """)
        pacientes = cursor.fetchall()
        
        return render_template('doctor/nueva_cita.html', pacientes=pacientes)
        
    except Exception as e:
        g.mysql.connection.rollback()
        flash(f'Error al crear la cita: {str(e)}', 'danger')
        return redirect(url_for('doctor.dashboard'))
    finally:
        cursor.close()


@doctor_bp.route('/citas-hoy')
@login_required
@role_required('doctor')
def citas_hoy():
    """API para obtener citas de hoy en JSON"""
    cursor = g.mysql.connection.cursor()
    try:
        hoy = date.today()
        
        cursor.execute("SELECT id FROM doctores WHERE usuario_id = %s", (session['usuario_id'],))
        doctor = cursor.fetchone()
        doctor_id = doctor[0]
        
        cursor.execute("""
            SELECT c.id, c.paciente_id, c.doctor_id, c.fecha_hora, c.duracion, 
                   c.motivo, c.estado, u.nombre_completo
            FROM citas c
            JOIN pacientes p ON c.paciente_id = p.id
            JOIN usuarios u ON p.usuario_id = u.id
            WHERE c.doctor_id = %s 
            AND DATE(c.fecha_hora) = %s
            ORDER BY c.fecha_hora ASC
        """, (doctor_id, hoy))
        
        citas = cursor.fetchall()
        
        resultado = {
            'citas': [
                {
                    'id': c[0],
                    'hora': c[3].strftime('%H:%M') if hasattr(c[3], 'strftime') else str(c[3]),
                    'paciente': c[7],
                    'motivo': c[5] or 'Consulta general',
                    'estado': c[6]
                }
                for c in citas
            ]
        }
        
        return jsonify(resultado)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        cursor.close()


# =====================================
# HISTORIAS CLÍNICAS
# =====================================
@doctor_bp.route('/historias-clinicas')
@login_required
@role_required('doctor')
def historias_clinicas():
    """Ver todas las historias clínicas"""
    cursor = g.mysql.connection.cursor()
    
    try:
        cursor.execute("SELECT id FROM doctores WHERE usuario_id = %s", (session['usuario_id'],))
        doctor = cursor.fetchone()
        doctor_id = doctor[0]
        
        query = """
            SELECT hc.*, u.nombre_completo as paciente_nombre, p.cedula
            FROM historias_clinicas hc
            JOIN pacientes p ON hc.paciente_id = p.id
            JOIN usuarios u ON p.usuario_id = u.id
            WHERE hc.doctor_id = %s
            ORDER BY hc.fecha_consulta DESC
        """
        cursor.execute(query, (doctor_id,))
        historias = cursor.fetchall()
        
        return render_template('doctor/historias_clinicas.html', historias=historias)
        
    except Exception as e:
        flash(f'Error al cargar historias clínicas: {str(e)}', 'danger')
        return redirect(url_for('doctor.dashboard'))
    finally:
        cursor.close()


@doctor_bp.route('/nueva-historia', methods=['GET', 'POST'])
@login_required
@role_required('doctor')
def nueva_historia():
    """Crear nueva historia clínica"""
    cursor = g.mysql.connection.cursor()
    
    try:
        cursor.execute("SELECT id FROM doctores WHERE usuario_id = %s", (session['usuario_id'],))
        doctor = cursor.fetchone()
        doctor_id = doctor[0]
        
        if request.method == 'POST':
            paciente_id = request.form.get('paciente_id')
            motivo_consulta = request.form.get('motivo_consulta')
            sintomas = request.form.get('sintomas')
            diagnostico = request.form.get('diagnostico')
            tratamiento = request.form.get('tratamiento')
            observaciones = request.form.get('observaciones')
            presion_arterial = request.form.get('presion_arterial')
            temperatura = request.form.get('temperatura')
            peso = request.form.get('peso')
            altura = request.form.get('altura')
            
            cursor.execute("""
                INSERT INTO historias_clinicas 
                (paciente_id, doctor_id, fecha_consulta, motivo_consulta, sintomas, 
                 diagnostico, tratamiento, observaciones, presion_arterial, 
                 temperatura, peso, altura)
                VALUES (%s, %s, NOW(), %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (paciente_id, doctor_id, motivo_consulta, sintomas, diagnostico, 
                  tratamiento, observaciones, presion_arterial, temperatura, peso, altura))
            
            g.mysql.connection.commit()
            registrar_auditoria(session['usuario_id'], 'crear_historia_clinica', 'historias_clinicas', paciente_id)
            
            flash('Historia clínica creada exitosamente', 'success')
            return redirect(url_for('doctor.historias_clinicas'))
        
        cursor.execute("""
            SELECT p.id, u.nombre_completo, u.cedula, p.tipo_sangre, p.alergias
            FROM pacientes p
            JOIN usuarios u ON p.usuario_id = u.id
            WHERE u.activo = TRUE
            ORDER BY u.nombre_completo
        """)
        pacientes = cursor.fetchall()
        
        return render_template('doctor/nueva_historia.html', pacientes=pacientes)
        
    except Exception as e:
        g.mysql.connection.rollback()
        flash(f'Error al crear historia clínica: {str(e)}', 'danger')
        return redirect(url_for('doctor.historias_clinicas'))
    finally:
        cursor.close()


@doctor_bp.route('/historia/<int:historia_id>')
@login_required
@role_required('doctor')
def ver_historia(historia_id):
    """Ver detalle de historia clínica"""
    cursor = g.mysql.connection.cursor()
    
    try:
        query = """
            SELECT hc.*, u.nombre_completo as paciente_nombre, p.cedula,
                   p.tipo_sangre, p.alergias, p.enfermedades_cronicas,
                   up.telefono, up.email, up.fecha_nacimiento, up.genero
            FROM historias_clinicas hc
            JOIN pacientes p ON hc.paciente_id = p.id
            JOIN usuarios u ON p.usuario_id = u.id
            JOIN usuarios up ON u.id = up.id
            WHERE hc.id = %s
        """
        cursor.execute(query, (historia_id,))
        historia = cursor.fetchone()
        
        if not historia:
            flash('Historia clínica no encontrada', 'danger')
            return redirect(url_for('doctor.historias_clinicas'))
        
        return render_template('doctor/ver_historia.html', historia=historia)
        
    except Exception as e:
        flash(f'Error al cargar historia clínica: {str(e)}', 'danger')
        return redirect(url_for('doctor.historias_clinicas'))
    finally:
        cursor.close()


@doctor_bp.route('/historia/<int:historia_id>/pdf')
@login_required
@role_required('doctor')
def descargar_historia_pdf(historia_id):
    """Generar y descargar historia clínica en PDF"""
    cursor = g.mysql.connection.cursor()
    
    try:
        query = """
            SELECT 
                hc.id, hc.paciente_id, hc.doctor_id, hc.fecha_consulta, 
                hc.motivo_consulta, hc.sintomas, hc.diagnostico, hc.tratamiento, 
                hc.observaciones, hc.presion_arterial, hc.temperatura, hc.peso, hc.altura,
                p.tipo_sangre, p.alergias, p.enfermedades_cronicas,
                up.nombre_completo as paciente_nombre, up.cedula as paciente_cedula,
                up.telefono as paciente_telefono, up.email as paciente_email,
                up.fecha_nacimiento, up.genero, up.direccion,
                ud.nombre_completo as doctor_nombre, d.firma_path
            FROM historias_clinicas hc
            JOIN pacientes p ON hc.paciente_id = p.id
            JOIN usuarios up ON p.usuario_id = up.id
            JOIN doctores d ON hc.doctor_id = d.id
            JOIN usuarios ud ON d.usuario_id = ud.id
            WHERE hc.id = %s
        """
        cursor.execute(query, (historia_id,))
        h = cursor.fetchone()
        
        if not h:
            flash('Historia clínica no encontrada', 'danger')
            return redirect(url_for('doctor.historias_clinicas'))
        
        def format_fecha(fecha_obj):
            if fecha_obj is None:
                return 'N/A'
            if isinstance(fecha_obj, str):
                return fecha_obj
            return fecha_obj.strftime('%d/%m/%Y %H:%M') if hasattr(fecha_obj, 'strftime') else str(fecha_obj)
        
        pdf_buffer = BytesIO()
        doc = SimpleDocTemplate(pdf_buffer, pagesize=A4, topMargin=0.5*inch, bottomMargin=0.5*inch)
        story = []
        styles = getSampleStyleSheet()
        
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=16,
            textColor=colors.HexColor('#1a3a52'),
            spaceAfter=6,
            alignment=TA_CENTER,
            fontName='Helvetica-Bold'
        )
        
        subtitle_style = ParagraphStyle(
            'Subtitle',
            parent=styles['Normal'],
            fontSize=10,
            textColor=colors.HexColor('#666666'),
            alignment=TA_CENTER,
            spaceAfter=20
        )
        
        section_style = ParagraphStyle(
            'SectionTitle',
            parent=styles['Heading2'],
            fontSize=11,
            textColor=colors.white,
            backColor=colors.HexColor('#4cd1ff'),
            spaceAfter=10,
            spaceBefore=10,
            fontName='Helvetica-Bold',
            leftIndent=5
        )
        
        label_style = ParagraphStyle(
            'Label',
            parent=styles['Normal'],
            fontSize=9,
            textColor=colors.HexColor('#1a3a52'),
            fontName='Helvetica-Bold'
        )
        
        story.append(Paragraph("CLÍNICA VITAL", title_style))
        story.append(Paragraph("Ibagué, Tolima | Tel: 01 8000 9544000", subtitle_style))
        story.append(Paragraph("_" * 80, styles['Normal']))
        story.append(Spacer(1, 0.15*inch))
        
        story.append(Paragraph("HISTORIA CLÍNICA", title_style))
        story.append(Paragraph(f"Fecha de Emisión: {datetime.now().strftime('%d/%m/%Y %H:%M')}", subtitle_style))
        story.append(Spacer(1, 0.2*inch))
        
        story.append(Paragraph("1. INFORMACIÓN DEL PACIENTE", section_style))
        
        patient_data = [
            ['Nombre Completo', h[16], 'Cédula', h[17]],
            ['Fecha de Nacimiento', format_fecha(h[20]), 'Género', h[21] if h[21] else 'N/A'],
            ['Teléfono', h[18] if h[18] else 'N/A', 'Email', h[19] if h[19] else 'N/A'],
        ]
        
        patient_table = Table(patient_data, colWidths=[1.8*inch, 1.8*inch, 1.8*inch, 1.8*inch])
        patient_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#e8f4f8')),
            ('BACKGROUND', (2, 0), (2, -1), colors.HexColor('#e8f4f8')),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.HexColor('#1a3a52')),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('LEFTPADDING', (0, 0), (-1, -1), 8),
            ('RIGHTPADDING', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#cccccc')),
        ]))
        story.append(patient_table)
        story.append(Spacer(1, 0.15*inch))
        
        story.append(Paragraph("2. INFORMACIÓN MÉDICA", section_style))
        
        medical_data = [
            ['Tipo de Sangre', h[13] if h[13] else 'N/A'],
            ['Alergias', h[14] if h[14] else 'Ninguna registrada'],
            ['Enfermedades Crónicas', h[15] if h[15] else 'Ninguna registrada'],
        ]
        
        medical_table = Table(medical_data, colWidths=[1.5*inch, 4.5*inch])
        medical_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#e8f4f8')),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.HexColor('#1a3a52')),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('LEFTPADDING', (0, 0), (-1, -1), 8),
            ('RIGHTPADDING', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#cccccc')),
        ]))
        story.append(medical_table)
        story.append(Spacer(1, 0.15*inch))
        
        story.append(Paragraph("3. CONSULTA ACTUAL", section_style))
        story.append(Paragraph(f"<b>Fecha de Consulta:</b> {format_fecha(h[3])}", label_style))
        story.append(Spacer(1, 0.08*inch))
        
        story.append(Paragraph("<b>Motivo de Consulta:</b>", label_style))
        story.append(Paragraph(h[4] if h[4] else 'No especificado', styles['Normal']))
        story.append(Spacer(1, 0.1*inch))
        
        story.append(Paragraph("<b>Síntomas Presentados:</b>", label_style))
        story.append(Paragraph(h[5] if h[5] else 'No especificados', styles['Normal']))
        story.append(Spacer(1, 0.1*inch))
        
        story.append(Paragraph("<b>Diagnóstico:</b>", label_style))
        story.append(Paragraph(h[6] if h[6] else 'No especificado', styles['Normal']))
        story.append(Spacer(1, 0.1*inch))
        
        story.append(Paragraph("<b>Tratamiento Recomendado:</b>", label_style))
        story.append(Paragraph(h[7] if h[7] else 'No especificado', styles['Normal']))
        
        if h[8]:
            story.append(Spacer(1, 0.1*inch))
            story.append(Paragraph("<b>Observaciones Adicionales:</b>", label_style))
            story.append(Paragraph(h[8], styles['Normal']))
        
        story.append(Spacer(1, 0.15*inch))
        
        story.append(Paragraph("4. SIGNOS VITALES", section_style))
        
        vitals_data = [
            ['Presión Arterial', h[9] if h[9] else 'N/A', 'Temperatura', f"{h[10]}°C" if h[10] else 'N/A'],
            ['Peso', f"{h[11]} kg" if h[11] else 'N/A', 'Altura', f"{h[12]} cm" if h[12] else 'N/A'],
        ]
        
        vitals_table = Table(vitals_data, colWidths=[1.8*inch, 1.8*inch, 1.8*inch, 1.8*inch])
        vitals_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#f0f0f0')),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.HexColor('#1a3a52')),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('LEFTPADDING', (0, 0), (-1, -1), 8),
            ('RIGHTPADDING', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#cccccc')),
        ]))
        story.append(vitals_table)
        story.append(Spacer(1, 0.25*inch))
        
        story.append(Paragraph("5. MÉDICO TRATANTE", section_style))
        story.append(Paragraph(f"<b>Dr(a). {h[23]}</b>", label_style))
        story.append(Spacer(1, 0.15*inch))
        
        if h[24]:
            firma_full_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', h[24])
            if os.path.exists(firma_full_path):
                story.append(Paragraph("Firma Digital:", label_style))
                story.append(Spacer(1, 0.05*inch))
                try:
                    from reportlab.platypus import Image
                    img = Image(firma_full_path, width=120, height=50)
                    story.append(img)
                except:
                    pass
        
        story.append(Spacer(1, 0.1*inch))
        story.append(Paragraph("_" * 80, styles['Normal']))
        story.append(Spacer(1, 0.08*inch))
        story.append(Paragraph(f"<b>Dr(a). {h[23]}</b><br/>Cédula: {h[17]}", ParagraphStyle('Center', parent=styles['Normal'], alignment=TA_CENTER)))
        
        story.append(Spacer(1, 0.2*inch))
        story.append(Paragraph(
            "Este documento es confidencial y está protegido por las leyes de privacidad médica.<br/>"
            "Clínica Vital © 2025 - Todos los derechos reservados<br/>"
            f"Generado: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}",
            ParagraphStyle('Footer', parent=styles['Normal'], fontSize=8, textColor=colors.grey, alignment=TA_CENTER)
        ))
        
        doc.build(story)
        pdf_buffer.seek(0)
        
        response = make_response(pdf_buffer.getvalue())
        response.headers['Content-Type'] = 'application/pdf'
        response.headers['Content-Disposition'] = f'attachment; filename=Historia_Clinica_{h[17]}_{historia_id}.pdf'
        response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
        
        return response
        
    except Exception as e:
        flash(f'Error al generar PDF: {str(e)}', 'danger')
        return redirect(url_for('doctor.ver_historia', historia_id=historia_id))
    finally:
        cursor.close()


# =====================================
# RECETAS
# =====================================
@doctor_bp.route('/prescribir-receta', methods=['GET', 'POST'])
@login_required
@role_required('doctor')
def prescribir_receta():
    """Crear nueva receta médica"""
    cursor = g.mysql.connection.cursor()
    
    try:
        cursor.execute("SELECT id FROM doctores WHERE usuario_id = %s", (session['usuario_id'],))
        doctor = cursor.fetchone()
        doctor_id = doctor[0]
        
        if request.method == 'POST':
            paciente_id = request.form.get('paciente_id')
            diagnostico = request.form.get('diagnostico')
            medicamentos = request.form.get('medicamentos')
            dosis = request.form.get('dosis')
            frecuencia = request.form.get('frecuencia')
            duracion = request.form.get('duracion')
            indicaciones = request.form.get('indicaciones')
            
            cursor.execute("""
                INSERT INTO recetas 
                (paciente_id, doctor_id, fecha_emision, diagnostico, medicamentos,
                 dosis, frecuencia, duracion, indicaciones, activa)
                VALUES (%s, %s, NOW(), %s, %s, %s, %s, %s, %s, TRUE)
            """, (paciente_id, doctor_id, diagnostico, medicamentos, dosis, 
                  frecuencia, duracion, indicaciones))
            
            g.mysql.connection.commit()
            registrar_auditoria(session['usuario_id'], 'crear_receta', 'recetas', paciente_id)
            
            flash('Receta médica creada exitosamente', 'success')
            return redirect(url_for('doctor.dashboard'))
        
        cursor.execute("""
            SELECT p.id, u.nombre_completo, u.cedula, p.alergias
            FROM pacientes p
            JOIN usuarios u ON p.usuario_id = u.id
            WHERE u.activo = TRUE
            ORDER BY u.nombre_completo
        """)
        pacientes = cursor.fetchall()
        
        return render_template('doctor/prescribir_receta.html', pacientes=pacientes)
        
    except Exception as e:
        g.mysql.connection.rollback()
        flash(f'Error al crear receta: {str(e)}', 'danger')
        return redirect(url_for('doctor.dashboard'))
    finally:
        cursor.close()


# =====================================
# PACIENTES
# =====================================
@doctor_bp.route('/pacientes')
@login_required
@role_required('doctor')
def ver_pacientes_doctor():
    """Ver lista de pacientes"""
    cursor = g.mysql.connection.cursor()
    
    try:
        query = """
            SELECT p.id, u.nombre_completo, u.cedula, u.telefono, u.email,
                   p.tipo_sangre, p.alergias, u.fecha_nacimiento, u.genero
            FROM pacientes p
            JOIN usuarios u ON p.usuario_id = u.id
            WHERE u.activo = TRUE
            ORDER BY u.nombre_completo
        """
        cursor.execute(query)
        pacientes_list = cursor.fetchall()
        
        return render_template('doctor/pacientes.html', pacientes=pacientes_list)
        
    except Exception as e:
        flash(f'Error al cargar pacientes: {str(e)}', 'danger')
        return redirect(url_for('doctor.dashboard'))
    finally:
        cursor.close()


@doctor_bp.route('/paciente/<int:paciente_id>')
@login_required
@role_required('doctor')
def ver_paciente(paciente_id):
    """Ver perfil completo de un paciente"""
    cursor = g.mysql.connection.cursor()
    
    try:
        query_paciente = """
            SELECT p.id, p.usuario_id, p.tipo_sangre, p.alergias, 
                   p.enfermedades_cronicas, p.contacto_emergencia, 
                   p.telefono_emergencia,
                   u.nombre_completo, u.cedula, u.email, u.telefono,
                   u.fecha_nacimiento, u.genero, u.direccion
            FROM pacientes p
            JOIN usuarios u ON p.usuario_id = u.id
            WHERE p.id = %s
        """
        cursor.execute(query_paciente, (paciente_id,))
        paciente = cursor.fetchone()
        
        if not paciente:
            flash('Paciente no encontrado', 'danger')
            return redirect(url_for('doctor.ver_pacientes_doctor'))
        
        cursor.execute("""
            SELECT hc.*, ud.nombre_completo as doctor_nombre
            FROM historias_clinicas hc
            JOIN doctores d ON hc.doctor_id = d.id
            JOIN usuarios ud ON d.usuario_id = ud.id
            WHERE hc.paciente_id = %s
            ORDER BY hc.fecha_consulta DESC
            LIMIT 5
        """, (paciente_id,))
        historias = cursor.fetchall()
        
        cursor.execute("""
            SELECT c.*, ud.nombre_completo as doctor_nombre
            FROM citas c
            JOIN doctores d ON c.doctor_id = d.id
            JOIN usuarios ud ON d.usuario_id = ud.id
            WHERE c.paciente_id = %s
            ORDER BY c.fecha_hora DESC
            LIMIT 5
        """, (paciente_id,))
        citas = cursor.fetchall()
        
        return render_template('doctor/ver_paciente.html', 
                             paciente=paciente, 
                             historias=historias,
                             citas=citas)
        
    except Exception as e:
        flash(f'Error al cargar información del paciente: {str(e)}', 'danger')
        return redirect(url_for('doctor.ver_pacientes_doctor'))
    finally:
        cursor.close()


# =====================================
# REPORTES
# =====================================
@doctor_bp.route('/reportes')
@login_required
@role_required('doctor')
def reportes():
    """Ver estadísticas y reportes"""
    cursor = g.mysql.connection.cursor()
    
    try:
        cursor.execute("SELECT id FROM doctores WHERE usuario_id = %s", (session['usuario_id'],))
        doctor = cursor.fetchone()
        doctor_id = doctor[0]
        
        cursor.execute("""
            SELECT COUNT(DISTINCT paciente_id) 
            FROM citas 
            WHERE doctor_id = %s AND estado = 'completada'
        """, (doctor_id,))
        total_pacientes = cursor.fetchone()[0]
        
        cursor.execute("""
            SELECT COUNT(*) 
            FROM historias_clinicas 
            WHERE doctor_id = %s
        """, (doctor_id,))
        total_consultas = cursor.fetchone()[0]
        
        cursor.execute("""
            SELECT COUNT(*) 
            FROM citas 
            WHERE doctor_id = %s AND MONTH(fecha_hora) = MONTH(CURDATE())
        """, (doctor_id,))
        citas_mes = cursor.fetchone()[0]
        
        cursor.execute("""
            SELECT COUNT(*) 
            FROM recetas 
            WHERE doctor_id = %s
        """, (doctor_id,))
        total_recetas = cursor.fetchone()[0]
        
        cursor.execute("""
            SELECT DATE_FORMAT(fecha_consulta, '%%Y-%%m') as mes, COUNT(*) as total
            FROM historias_clinicas
            WHERE doctor_id = %s AND fecha_consulta >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
            GROUP BY mes
            ORDER BY mes
        """, (doctor_id,))
        consultas_mensuales = cursor.fetchall()
        
        return render_template('doctor/reportes.html',
                             total_pacientes=total_pacientes,
                             total_consultas=total_consultas,
                             citas_mes=citas_mes,
                             total_recetas=total_recetas,
                             consultas_mensuales=consultas_mensuales)
        
    except Exception as e:
        flash(f'Error al cargar reportes: {str(e)}', 'danger')
        return redirect(url_for('doctor.dashboard'))
    finally:
        cursor.close()


# =====================================
# MENSAJES
# =====================================
@doctor_bp.route('/mensajes')
@login_required
@role_required('doctor')
def mensajes():
    """Ver mensajes con pacientes"""
    cursor = g.mysql.connection.cursor()
    
    try:
        cursor.execute("SELECT id FROM doctores WHERE usuario_id = %s", (session['usuario_id'],))
        doctor = cursor.fetchone()
        
        if not doctor:
            flash('No se encontró información del doctor', 'danger')
            return redirect(url_for('doctor.dashboard'))
        
        doctor_id = doctor[0]
        
        query = """
            SELECT DISTINCT p.id, u.nombre_completo as paciente_nombre, 
                   u.cedula, COUNT(m.id) as sin_leer
            FROM pacientes p
            JOIN usuarios u ON p.usuario_id = u.id
            LEFT JOIN mensajes m ON (m.paciente_id = p.id AND m.doctor_id = %s AND m.leido = FALSE)
            WHERE u.activo = TRUE
            GROUP BY p.id, u.nombre_completo, u.cedula
            ORDER BY sin_leer DESC, u.nombre_completo
        """
        cursor.execute(query, (doctor_id,))
        conversaciones = cursor.fetchall()
        
        return render_template('doctor/mensajes.html', conversaciones=conversaciones)
        
    except Exception as e:
        flash(f'Error al cargar mensajes: {str(e)}', 'danger')
        return redirect(url_for('doctor.dashboard'))
    finally:
        cursor.close()


@doctor_bp.route('/mensajes/<int:paciente_id>')
@login_required
@role_required('doctor')
def ver_conversacion_paciente(paciente_id):
    """Ver conversación con un paciente específico"""
    cursor = g.mysql.connection.cursor()
    
    try:
        cursor.execute("SELECT id FROM doctores WHERE usuario_id = %s", (session['usuario_id'],))
        doctor = cursor.fetchone()
        
        if not doctor:
            flash('No se encontró información del doctor', 'danger')
            return redirect(url_for('doctor.dashboard'))
        
        doctor_id = doctor[0]
        
        query_paciente = """
            SELECT p.id, u.nombre_completo, u.cedula, u.email, u.telefono
            FROM pacientes p
            JOIN usuarios u ON p.usuario_id = u.id
            WHERE p.id = %s AND u.activo = TRUE
        """
        cursor.execute(query_paciente, (paciente_id,))
        paciente = cursor.fetchone()
        
        if not paciente:
            flash('Paciente no encontrado', 'danger')
            return redirect(url_for('doctor.mensajes'))
        
        cursor.execute("""
            UPDATE mensajes 
            SET leido = TRUE 
            WHERE paciente_id = %s AND doctor_id = %s AND remitente = 'paciente'
        """, (paciente_id, doctor_id))
        g.mysql.connection.commit()
        
        query_mensajes = """
            SELECT id, remitente, contenido, fecha_hora
            FROM mensajes
            WHERE (paciente_id = %s AND doctor_id = %s)
            ORDER BY fecha_hora ASC
        """
        cursor.execute(query_mensajes, (paciente_id, doctor_id))
        mensajes = cursor.fetchall()
        
        return render_template('doctor/ver_conversacion_paciente.html', paciente=paciente, mensajes=mensajes, doctor_id=doctor_id)
        
    except Exception as e:
        flash(f'Error al cargar conversación: {str(e)}', 'danger')
        return redirect(url_for('doctor.mensajes'))
    finally:
        cursor.close()


@doctor_bp.route('/mensajes/<int:paciente_id>/enviar', methods=['POST'])
@login_required
@role_required('doctor')
def enviar_mensaje_paciente(paciente_id):
    """Enviar mensaje a un paciente"""
    cursor = g.mysql.connection.cursor()
    
    try:
        cursor.execute("SELECT id FROM doctores WHERE usuario_id = %s", (session['usuario_id'],))
        doctor = cursor.fetchone()
        
        if not doctor:
            flash('No se encontró información del doctor', 'danger')
            return redirect(url_for('doctor.dashboard'))
        
        doctor_id = doctor[0]
        contenido = request.form.get('contenido', '').strip()
        
        if not contenido:
            flash('El mensaje no puede estar vacío', 'warning')
            return redirect(url_for('doctor.ver_conversacion_paciente', paciente_id=paciente_id))
        
        cursor.execute("""
            INSERT INTO mensajes (paciente_id, doctor_id, remitente, contenido)
            VALUES (%s, %s, 'doctor', %s)
        """, (paciente_id, doctor_id, contenido))
        
        g.mysql.connection.commit()
        registrar_auditoria(session['usuario_id'], 'enviar_mensaje', 'mensajes', paciente_id)
        
        flash('Mensaje enviado exitosamente', 'success')
        return redirect(url_for('doctor.ver_conversacion_paciente', paciente_id=paciente_id))
        
    except Exception as e:
        g.mysql.connection.rollback()
        flash(f'Error al enviar mensaje: {str(e)}', 'danger')
        return redirect(url_for('doctor.ver_conversacion_paciente', paciente_id=paciente_id))
    finally:
        cursor.close()


# =====================================
# PERFIL
# =====================================
@doctor_bp.route('/mi-perfil', methods=['GET', 'POST'])
@login_required
@role_required('doctor')
def mi_perfil():
    """Ver y editar perfil del doctor"""
    cursor = g.mysql.connection.cursor()
    
    try:
        cursor.execute("SELECT id FROM doctores WHERE usuario_id = %s", (session['usuario_id'],))
        doctor = cursor.fetchone()
        doctor_id = doctor[0]
        
        if request.method == 'POST':
            # Manejar subida de firma
            if 'firma' in request.files:
                file = request.files['firma']
                
                if file and file.filename != '':
                    if allowed_file(file.filename):
                        ext = file.filename.rsplit('.', 1)[1].lower()
                        filename = secure_filename(f'firma_doctor_{doctor_id}.{ext}')
                        
                        upload_folder = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', 'uploads', 'firmas')
                        os.makedirs(upload_folder, exist_ok=True)
                        
                        filepath = os.path.join(upload_folder, filename)
                        file.save(filepath)
                        
                        firma_path = f'uploads/firmas/{filename}'
                        cursor.execute("UPDATE doctores SET firma_path = %s WHERE id = %s", 
                                     (firma_path, doctor_id))
                        g.mysql.connection.commit()
                        
                        flash('✅ Firma actualizada correctamente', 'success')
                    else:
                        flash('❌ Solo se permiten imágenes PNG, JPG o JPEG', 'danger')
            
            # Actualizar datos del perfil (AHORA INCLUYE EMAIL Y CEDULA)
            nombre = request.form.get('nombre_completo')
            email = request.form.get('email')
            telefono = request.form.get('telefono')
            cedula = request.form.get('cedula')
            
            if nombre or email or telefono or cedula:
                try:
                    cursor.execute("""
                        UPDATE usuarios
                        SET nombre_completo = COALESCE(%s, nombre_completo),
                            email = COALESCE(%s, email),
                            telefono = COALESCE(%s, telefono),
                            cedula = COALESCE(%s, cedula)
                        WHERE id = %s
                    """, (nombre if nombre else None, 
                          email if email else None,
                          telefono if telefono else None, 
                          cedula if cedula else None,
                          session['usuario_id']))
                    g.mysql.connection.commit()
                    flash('✅ Perfil actualizado', 'success')
                except Exception as e:
                    if 'Duplicate' in str(e) or 'duplicate' in str(e).lower():
                        flash('❌ El correo o la cédula ya están en uso', 'danger')
                    else:
                        flash(f'❌ Error al actualizar: {str(e)}', 'danger')
            
            return redirect(url_for('doctor.mi_perfil'))
        
        # GET - Mostrar perfil
        cursor.execute("""
            SELECT u.nombre_completo, u.email, u.telefono, u.cedula, d.firma_path
            FROM usuarios u
            JOIN doctores d ON u.id = d.usuario_id
            WHERE d.usuario_id = %s
        """, (session['usuario_id'],))
        
        perfil = cursor.fetchone()
        
        return render_template('doctor/mi_perfil.html', perfil=perfil)
        
    except Exception as e:
        flash(f'❌ Error: {str(e)}', 'danger')
        return redirect(url_for('doctor.dashboard'))
    finally:
        cursor.close()
