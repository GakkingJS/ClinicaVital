from flask import Blueprint, render_template, request, redirect, url_for, flash, session, g
from werkzeug.security import generate_password_hash
from datetime import datetime
import secrets
from utils.decorators import login_required, role_required
from utils.helpers import registrar_auditoria
from flask import make_response, send_file
from datetime import datetime
import csv
import io
import os
import subprocess
from datetime import datetime
from flask import render_template, redirect, url_for, flash, send_file, session, g
from utils.decorators import login_required, role_required
from werkzeug.security import generate_password_hash
from utils.helpers import registrar_auditoria






admin_bp = Blueprint('admin', __name__, template_folder='templates')


# --- DASHBOARD PRINCIPAL ---
@admin_bp.route('/dashboard')
@login_required
@role_required('admin')
def dashboard():
    """Dashboard principal del administrador"""
    cursor = g.mysql.connection.cursor()
    
    try:
        # Total de usuarios
        cursor.execute("SELECT COUNT(*) FROM usuarios WHERE activo = TRUE")
        total_usuarios = cursor.fetchone()[0]
        
        # Citas de hoy
        cursor.execute("""
            SELECT COUNT(*) FROM citas 
            WHERE DATE(fecha_hora) = CURDATE()
        """)
        citas_hoy = cursor.fetchone()[0]
        
        # Consultas de hoy
        cursor.execute("""
            SELECT COUNT(*) FROM historias_clinicas 
            WHERE DATE(fecha_consulta) = CURDATE()
        """)
        consultas_hoy = cursor.fetchone()[0]
        
        # Últimos 5 usuarios con sus roles CORRECTAMENTE
        query_usuarios = """
            SELECT u.id, u.username, u.email, r.nombre as rol_nombre, 
                   u.nombre_completo, u.activo
            FROM usuarios u
            JOIN roles r ON u.rol_id = r.id
            ORDER BY u.id DESC
            LIMIT 5
        """
        cursor.execute(query_usuarios)
        usuarios = cursor.fetchall()
        
        return render_template('admin/dashboard.html',
                             total_usuarios=total_usuarios,
                             citas_hoy=citas_hoy,
                             consultas_hoy=consultas_hoy,
                             usuarios=usuarios)
        
    except Exception as e:
        flash(f'❌ Error al cargar dashboard: {str(e)}', 'danger')
        return redirect(url_for('admin.dashboard'))
    finally:
        cursor.close()


# --- USUARIOS ---
@admin_bp.route('/usuarios')
@login_required
@role_required('admin')
def ver_usuarios():
    """Ver lista de usuarios"""
    cursor = g.mysql.connection.cursor()
    
    try:
        query = """
            SELECT 
                u.id,
                u.username,
                u.email,
                CASE 
                    WHEN u.rol_id = 4 THEN 'Paciente'
                    WHEN u.rol_id = 2 THEN 'Doctor'
                    WHEN u.rol_id = 3 THEN 'Secretaria'
                    WHEN u.rol_id = 1 THEN 'Administrador'
                    ELSE 'Otro'
                END as rol,
                u.nombre_completo,
                u.activo
            FROM usuarios u
            ORDER BY u.id DESC
        """
        cursor.execute(query)
        usuarios = cursor.fetchall()
        
        return render_template('admin/usuarios.html', usuarios=usuarios)
        
    except Exception as e:
        flash(f'Error al cargar usuarios: {str(e)}', 'danger')
        return redirect(url_for('admin.dashboard'))
    finally:
        cursor.close()


# --- VER DETALLES DE USUARIO ---
@admin_bp.route('/usuario/<int:usuario_id>')
@login_required
@role_required('admin')
def ver_usuario(usuario_id):
    """Ver detalles de un usuario"""
    cursor = g.mysql.connection.cursor()
    
    try:
        query = """
            SELECT 
                u.id, u.username, u.email, u.nombre_completo, u.telefono, u.cedula,
                u.fecha_nacimiento, u.direccion, u.activo, u.rol_id,
                CASE 
                    WHEN u.rol_id = 1 THEN 'Paciente'
                    WHEN u.rol_id = 2 THEN 'Doctor'
                    WHEN u.rol_id = 3 THEN 'Secretaria'
                    WHEN u.rol_id = 4 THEN 'Administrador'
                    ELSE 'Otro'
                END as rol
            FROM usuarios u
            WHERE u.id = %s
        """
        cursor.execute(query, (usuario_id,))
        usuario = cursor.fetchone()
        
        if not usuario:
            flash('Usuario no encontrado', 'danger')
            return redirect(url_for('admin.ver_usuarios'))
        
        return render_template('admin/ver_usuario.html', usuario=usuario)
        
    except Exception as e:
        flash(f'Error al cargar usuario: {str(e)}', 'danger')
        return redirect(url_for('admin.ver_usuarios'))
    finally:
        cursor.close()


# --- EDITAR USUARIO ---
@admin_bp.route('/usuario/<int:usuario_id>/editar', methods=['GET', 'POST'])
@login_required
@role_required('admin')
def editar_usuario(usuario_id):
    """Editar datos de un usuario"""
    cursor = g.mysql.connection.cursor()
    
    try:
        if request.method == 'POST':
            email = request.form.get('email')
            nombre_completo = request.form.get('nombre_completo')
            telefono = request.form.get('telefono')
            cedula = request.form.get('cedula')
            fecha_nacimiento = request.form.get('fecha_nacimiento')
            direccion = request.form.get('direccion')
            
            if not all([email, nombre_completo]):
                flash('Por favor completa los campos requeridos', 'warning')
                return redirect(url_for('admin.editar_usuario', usuario_id=usuario_id))
            
            cursor.execute("SELECT id FROM usuarios WHERE email = %s AND id != %s", (email, usuario_id))
            if cursor.fetchone():
                flash('El email ya está en uso por otro usuario', 'danger')
                return redirect(url_for('admin.editar_usuario', usuario_id=usuario_id))
            
            cursor.execute("""
                UPDATE usuarios 
                SET email = %s, nombre_completo = %s, telefono = %s, 
                    cedula = %s, fecha_nacimiento = %s, direccion = %s
                WHERE id = %s
            """, (email, nombre_completo, telefono, cedula, fecha_nacimiento, direccion, usuario_id))
            
            g.mysql.connection.commit()
            
            flash('Usuario actualizado exitosamente', 'success')
            return redirect(url_for('admin.ver_usuario', usuario_id=usuario_id))
        
        query = """
            SELECT 
                u.id, u.username, u.email, u.nombre_completo, u.telefono, u.cedula,
                u.fecha_nacimiento, u.direccion, u.activo, u.rol_id,
                CASE 
                    WHEN u.rol_id = 1 THEN 'Paciente'
                    WHEN u.rol_id = 2 THEN 'Doctor'
                    WHEN u.rol_id = 3 THEN 'Secretaria'
                    WHEN u.rol_id = 4 THEN 'Administrador'
                    ELSE 'Otro'
                END as rol
            FROM usuarios u
            WHERE u.id = %s
        """
        cursor.execute(query, (usuario_id,))
        usuario = cursor.fetchone()
        
        if not usuario:
            flash('Usuario no encontrado', 'danger')
            return redirect(url_for('admin.ver_usuarios'))
        
        return render_template('admin/editar_usuario.html', usuario=usuario)
        
    except Exception as e:
        g.mysql.connection.rollback()
        flash(f'Error: {str(e)}', 'danger')
        return redirect(url_for('admin.ver_usuarios'))
    finally:
        cursor.close()


# --- DESACTIVAR/ACTIVAR USUARIO ---
@admin_bp.route('/usuario/<int:usuario_id>/toggle-estado', methods=['POST'])
@login_required
@role_required('admin')
def toggle_usuario_estado(usuario_id):
    """Activar o desactivar un usuario"""
    cursor = g.mysql.connection.cursor()
    
    try:
        cursor.execute("SELECT activo FROM usuarios WHERE id = %s", (usuario_id,))
        resultado = cursor.fetchone()
        
        if not resultado:
            flash('Usuario no encontrado', 'danger')
            return redirect(url_for('admin.ver_usuarios'))
        
        activo_actual = resultado[0]
        nuevo_estado = not activo_actual
        
        cursor.execute("UPDATE usuarios SET activo = %s WHERE id = %s", (nuevo_estado, usuario_id))
        g.mysql.connection.commit()
        
        estado_texto = 'activado' if nuevo_estado else 'desactivado'
        flash(f'Usuario {estado_texto} exitosamente', 'success')
        
    except Exception as e:
        g.mysql.connection.rollback()
        flash(f'Error al cambiar estado: {str(e)}', 'danger')
    finally:
        cursor.close()
    
    return redirect(url_for('admin.ver_usuarios'))


# --- CREAR DOCTOR ---
@admin_bp.route('/crear_doctor', methods=['GET', 'POST'])
@login_required
@role_required('admin')
def crear_doctor():
    """Crear nuevo doctor"""
    cursor = g.mysql.connection.cursor()
    
    try:
        if request.method == 'POST':
            nombre_completo = request.form.get('nombre_completo')
            cedula = request.form.get('cedula')  # ← NUEVO
            email = request.form.get('email')
            telefono = request.form.get('telefono')
            fecha_nacimiento = request.form.get('fecha_nacimiento')
            especialidad_id = request.form.get('especialidad_id')
            numero_licencia = request.form.get('numero_licencia')
            anos_experiencia = request.form.get('anos_experiencia')
            direccion = request.form.get('direccion')
            
            if not all([cedula, email, nombre_completo, especialidad_id]):
                flash('Por favor completa todos los campos requeridos', 'warning')
                return redirect(url_for('admin.crear_doctor'))
            
            # Verificar cédula y email únicos
            cursor.execute("SELECT id FROM usuarios WHERE cedula = %s OR email = %s", (cedula, email))
            if cursor.fetchone():
                flash('La cédula o email ya existe', 'danger')
                return redirect(url_for('admin.crear_doctor'))
            
            # ← CAMBIO: Contraseña temporal = cédula
            password_hash = generate_password_hash(cedula)
            
            cursor.execute("""
                INSERT INTO usuarios (cedula, email, password, nombre_completo, 
                                    telefono, fecha_nacimiento, direccion, username, activo, rol_id)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, TRUE, 2)
            """, (cedula, email, password_hash, nombre_completo, telefono, fecha_nacimiento, direccion, cedula))
            
            usuario_id = cursor.lastrowid
            
            # Validar que numero_licencia no esté vacío
            numero_licencia = numero_licencia.strip() if numero_licencia else None
            
            cursor.execute("""
                INSERT INTO doctores (usuario_id, especialidad_id, numero_licencia, anos_experiencia)
                VALUES (%s, %s, %s, %s)
            """, (usuario_id, especialidad_id, numero_licencia, anos_experiencia or 0))
            
            g.mysql.connection.commit()
            
            # ← CAMBIO: Mostrar cédula como contraseña
            flash(f'✅ Doctor {nombre_completo} creado exitosamente. Contraseña temporal: {cedula}', 'success')
            return redirect(url_for('admin.ver_usuarios'))
        
        cursor.execute("SELECT id, nombre FROM especialidades ORDER BY nombre")
        especialidades = cursor.fetchall()
        
        return render_template('admin/crear_doctor.html', especialidades=especialidades)
        
    except Exception as e:
        g.mysql.connection.rollback()
        flash(f'❌ Error al crear doctor: {str(e)}', 'danger')
        return redirect(url_for('admin.crear_doctor'))
    finally:
        cursor.close()


# --- CREAR SECRETARIA ---
@admin_bp.route('/crear_secretaria', methods=['GET', 'POST'])
@login_required
@role_required('admin')
def crear_secretaria():
    """Crear nueva secretaria"""
    cursor = g.mysql.connection.cursor()
    
    try:
        if request.method == 'POST':
            nombre_completo = request.form.get('nombre_completo')
            cedula = request.form.get('cedula')  # ← NUEVO
            email = request.form.get('email')
            telefono = request.form.get('telefono')
            fecha_nacimiento = request.form.get('fecha_nacimiento')
            direccion = request.form.get('direccion')
            
            if not all([cedula, email, nombre_completo]):
                flash('Por favor completa todos los campos requeridos', 'warning')
                return redirect(url_for('admin.crear_secretaria'))
            
            # Verificar cédula y email únicos
            cursor.execute("SELECT id FROM usuarios WHERE cedula = %s OR email = %s", (cedula, email))
            if cursor.fetchone():
                flash('La cédula o email ya existe', 'danger')
                return redirect(url_for('admin.crear_secretaria'))
            
            # ← CAMBIO: Contraseña temporal = cédula
            password_hash = generate_password_hash(cedula)
            
            cursor.execute("""
                INSERT INTO usuarios (cedula, email, password, nombre_completo, 
                                    telefono, fecha_nacimiento, direccion, username, activo, rol_id)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, TRUE, 3)
            """, (cedula, email, password_hash, nombre_completo, telefono, fecha_nacimiento, direccion, cedula))
            
            usuario_id = cursor.lastrowid
            
            # Insertar en tabla secretarias si existe
            try:
                cursor.execute("""
                    INSERT INTO secretarias (usuario_id)
                    VALUES (%s)
                """, (usuario_id,))
            except:
                pass  # Si la tabla no existe, continuar
            
            g.mysql.connection.commit()
            
            # ← CAMBIO: Mostrar cédula como contraseña
            flash(f'✅ Secretaria {nombre_completo} creada exitosamente. Contraseña temporal: {cedula}', 'success')
            return redirect(url_for('admin.ver_usuarios'))
        
        return render_template('admin/crear_secretaria.html')
        
    except Exception as e:
        g.mysql.connection.rollback()
        flash(f'❌ Error al crear secretaria: {str(e)}', 'danger')
        return redirect(url_for('admin.crear_secretaria'))
    finally:
        cursor.close()


# --- CREAR ADMIN ---
@admin_bp.route('/crear_admin', methods=['GET', 'POST'])
@login_required
@role_required('admin')
def crear_admin():
    """Crear nuevo administrador"""
    cursor = g.mysql.connection.cursor()
    
    try:
        if request.method == 'POST':
            nombre_completo = request.form.get('nombre_completo')
            cedula = request.form.get('cedula')  # ← NUEVO
            email = request.form.get('email')
            telefono = request.form.get('telefono')
            fecha_nacimiento = request.form.get('fecha_nacimiento')
            direccion = request.form.get('direccion')
            
            if not all([cedula, email, nombre_completo]):
                flash('Por favor completa todos los campos requeridos', 'warning')
                return redirect(url_for('admin.crear_admin'))
            
            # Verificar cédula y email únicos
            cursor.execute("SELECT id FROM usuarios WHERE cedula = %s OR email = %s", (cedula, email))
            if cursor.fetchone():
                flash('La cédula o email ya existe', 'danger')
                return redirect(url_for('admin.crear_admin'))
            
            # ← CAMBIO: Contraseña temporal = cédula
            password_hash = generate_password_hash(cedula)
            
            cursor.execute("""
                INSERT INTO usuarios (cedula, email, password, nombre_completo, 
                                    telefono, fecha_nacimiento, direccion, username, activo, rol_id)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, TRUE, 1)
            """, (cedula, email, password_hash, nombre_completo, telefono, fecha_nacimiento, direccion, cedula))
            
            g.mysql.connection.commit()
            
            # ← CAMBIO: Mostrar cédula como contraseña
            flash(f'✅ Administrador {nombre_completo} creado exitosamente. Contraseña temporal: {cedula}', 'success')
            return redirect(url_for('admin.ver_usuarios'))
        
        return render_template('admin/crear_admin.html')
        
    except Exception as e:
        g.mysql.connection.rollback()
        flash(f'❌ Error al crear administrador: {str(e)}', 'danger')
        return redirect(url_for('admin.crear_admin'))
    finally:
        cursor.close()


# --- ESPECIALIDADES ---
@admin_bp.route('/especialidades')
@login_required
@role_required('admin')
def ver_especialidades():
    """Ver especialidades"""
    cursor = g.mysql.connection.cursor()
    
    try:
        cursor.execute("SELECT id, nombre, descripcion, activo FROM especialidades ORDER BY nombre ASC")
        especialidades = cursor.fetchall()
        
        return render_template('admin/especialidades.html', especialidades=especialidades)
        
    except Exception as e:
        flash(f'Error: {str(e)}', 'danger')
        return redirect(url_for('admin.dashboard'))
    finally:
        cursor.close()


@admin_bp.route('/especialidades/crear', methods=['POST'])
@login_required
@role_required('admin')
def crear_especialidad():
    """Crear especialidad"""
    cursor = g.mysql.connection.cursor()
    
    try:
        nombre = request.form.get('nombre')
        descripcion = request.form.get('descripcion', '')
        
        if not nombre:
            flash('El nombre de la especialidad es requerido', 'warning')
            return redirect(url_for('admin.ver_especialidades'))
        
        cursor.execute("INSERT INTO especialidades (nombre, descripcion, activo) VALUES (%s, %s, 1)", 
                      (nombre, descripcion))
        g.mysql.connection.commit()
        
        flash('Especialidad creada exitosamente', 'success')
        return redirect(url_for('admin.ver_especialidades'))
        
    except Exception as e:
        g.mysql.connection.rollback()
        flash(f'Error: {str(e)}', 'danger')
        return redirect(url_for('admin.ver_especialidades'))
    finally:
        cursor.close()


@admin_bp.route('/especialidades/desactivar/<int:especialidad_id>', methods=['POST'])
@login_required
@role_required('admin')
def desactivar_especialidad(especialidad_id):
    """Desactivar especialidad"""
    cursor = g.mysql.connection.cursor()
    
    try:
        cursor.execute("UPDATE especialidades SET activo = 0 WHERE id = %s", (especialidad_id,))
        g.mysql.connection.commit()
        
        flash('Especialidad desactivada correctamente', 'warning')
        return redirect(url_for('admin.ver_especialidades'))
        
    except Exception as e:
        g.mysql.connection.rollback()
        flash(f'Error: {str(e)}', 'danger')
        return redirect(url_for('admin.ver_especialidades'))
    finally:
        cursor.close()


@admin_bp.route('/especialidades/activar/<int:especialidad_id>', methods=['POST'])
@login_required
@role_required('admin')
def activar_especialidad(especialidad_id):
    """Activar especialidad"""
    cursor = g.mysql.connection.cursor()
    
    try:
        cursor.execute("UPDATE especialidades SET activo = 1 WHERE id = %s", (especialidad_id,))
        g.mysql.connection.commit()
        
        flash('Especialidad activada correctamente', 'success')
        return redirect(url_for('admin.ver_especialidades'))
        
    except Exception as e:
        g.mysql.connection.rollback()
        flash(f'Error: {str(e)}', 'danger')
        return redirect(url_for('admin.ver_especialidades'))
    finally:
        cursor.close()


# --- REPORTES ---
@admin_bp.route('/reportes')
@login_required
@role_required('admin')
def ver_reportes():
    """Ver reportes y estadísticas"""
    cursor = g.mysql.connection.cursor()
    
    try:
        cursor.execute("SELECT COUNT(*) FROM usuarios WHERE activo = TRUE")
        total_usuarios = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM usuarios WHERE rol_id = 2")
        total_doctores = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM usuarios WHERE rol_id = 1")
        total_pacientes = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM citas")
        total_citas = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM historias_clinicas")
        total_historias = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM recetas")
        total_recetas = cursor.fetchone()[0]
        
        return render_template('admin/reportes.html',
                             total_usuarios=total_usuarios,
                             total_doctores=total_doctores,
                             total_pacientes=total_pacientes,
                             total_citas=total_citas,
                             total_historias=total_historias,
                             total_recetas=total_recetas)
        
    except Exception as e:
        flash(f'Error: {str(e)}', 'danger')
        return redirect(url_for('admin.dashboard'))
    finally:
        cursor.close()


# --- AUDITORÍA ---
@admin_bp.route('/auditoria')
@login_required
@role_required('admin')
def ver_auditoria():
    """Ver auditoría"""
    cursor = g.mysql.connection.cursor()
    
    try:
        query = """
            SELECT id, usuario_id, accion, modulo, fecha_accion, 
                   COALESCE(detalles, 'Sin detalles') as detalles
            FROM auditoria
            ORDER BY fecha_accion DESC
            LIMIT 100
        """
        cursor.execute(query)
        registros = cursor.fetchall()
        
        # Si no hay registros, enviar lista vacía
        if not registros:
            registros = []
        
        return render_template('admin/auditoria.html', registros=registros)
        
    except Exception as e:
        flash(f'Error: {str(e)}', 'danger')
        return render_template('admin/auditoria.html', registros=[])
    finally:
        cursor.close()



# --- ROLES ---
@admin_bp.route('/roles')
@login_required
@role_required('admin')
def ver_roles():
    """Gestionar roles y permisos"""
    cursor = g.mysql.connection.cursor()
    
    try:
        # Obtener roles
        cursor.execute("SELECT id, nombre, descripcion FROM roles ORDER BY id")
        roles = cursor.fetchall()
        
        # Obtener permisos por rol
        permisos_dict = {}
        for rol in roles:
            cursor.execute("""
                SELECT p.nombre, p.descripcion
                FROM permisos p
                JOIN rol_permisos rp ON p.id = rp.permiso_id
                WHERE rp.rol_id = %s
                ORDER BY p.modulo, p.nombre
            """, (rol[0],))
            permisos_dict[rol[0]] = [{'nombre': p[0], 'descripcion': p[1]} for p in cursor.fetchall()]
        
        return render_template('admin/roles.html', roles=roles, permisos_dict=permisos_dict)
        
    except Exception as e:
        flash(f'Error: {str(e)}', 'danger')
        return redirect(url_for('admin.dashboard'))
    finally:
        cursor.close()


# --- CONFIGURACIÓN ---
@admin_bp.route('/configuracion')
@login_required
@role_required('admin')
def ver_configuracion():
    """Ver configuración"""
    cursor = g.mysql.connection.cursor()
    
    try:
        cursor.execute("SELECT clave, valor, descripcion FROM configuracion ORDER BY clave")
        configs = cursor.fetchall()
        
        config_dict = {}
        for config in configs:
            config_dict[config[0]] = {'valor': config[1], 'descripcion': config[2]}
        
        return render_template('admin/configuracion.html', configuracion=config_dict)
        
    except Exception as e:
        flash(f'Error: {str(e)}', 'danger')
        return redirect(url_for('admin.dashboard'))
    finally:
        cursor.close()


@admin_bp.route('/configuracion/editar', methods=['POST'])
@login_required
@role_required('admin')
def editar_configuracion():
    """Editar configuración"""
    cursor = g.mysql.connection.cursor()
    
    try:
        nombre_clinica = request.form.get('nombre_clinica')
        email_clinica = request.form.get('email_clinica')
        telefono_clinica = request.form.get('telefono_clinica')
        direccion_clinica = request.form.get('direccion_clinica')
        horario_atencion = request.form.get('horario_atencion')
        
        # Actualizar cada campo
        cursor.execute("UPDATE configuracion SET valor = %s WHERE clave = 'nombre_clinica'", (nombre_clinica,))
        cursor.execute("UPDATE configuracion SET valor = %s WHERE clave = 'email_clinica'", (email_clinica,))
        cursor.execute("UPDATE configuracion SET valor = %s WHERE clave = 'telefono_clinica'", (telefono_clinica,))
        cursor.execute("UPDATE configuracion SET valor = %s WHERE clave = 'direccion_clinica'", (direccion_clinica,))
        cursor.execute("UPDATE configuracion SET valor = %s WHERE clave = 'horario_atencion'", (horario_atencion,))
        
        g.mysql.connection.commit()
        
        flash('Configuración actualizada exitosamente', 'success')
        return redirect(url_for('admin.ver_configuracion'))
        
    except Exception as e:
        g.mysql.connection.rollback()
        flash(f'Error: {str(e)}', 'danger')
        return redirect(url_for('admin.ver_configuracion'))
    finally:
        cursor.close()





# --- NOTIFICACIONES ---
@admin_bp.route('/notificaciones', methods=['GET', 'POST'])
@login_required
@role_required('admin')
def notificaciones():
    """Enviar notificaciones masivas"""
    
    if request.method == 'POST':
        titulo = request.form.get('titulo')
        mensaje = request.form.get('mensaje')
        destinatarios = request.form.get('destinatarios')
        
        cursor = g.mysql.connection.cursor()
        
        try:
            if destinatarios == 'todos':
                cursor.execute("SELECT id FROM usuarios WHERE activo = TRUE")
            elif destinatarios == 'doctores':
                cursor.execute("SELECT id FROM usuarios WHERE rol_id = 2 AND activo = TRUE")
            elif destinatarios == 'pacientes':
                cursor.execute("SELECT id FROM usuarios WHERE rol_id = 1 AND activo = TRUE")
            elif destinatarios == 'secretarias':
                cursor.execute("SELECT id FROM usuarios WHERE rol_id = 3 AND activo = TRUE")
            else:
                flash('Destinatario inválido', 'warning')
                return redirect(url_for('admin.notificaciones'))
            
            usuarios = cursor.fetchall()
            
            for usuario in usuarios:
                cursor.execute("""
                    INSERT INTO notificaciones (usuario_id, titulo, mensaje, leida, fecha_creacion)
                    VALUES (%s, %s, %s, FALSE, NOW())
                """, (usuario[0], titulo, mensaje))
            
            g.mysql.connection.commit()
            
            flash(f'Notificación enviada a {len(usuarios)} usuario(s)', 'success')
            return redirect(url_for('admin.notificaciones'))
            
        except Exception as e:
            g.mysql.connection.rollback()
            flash(f'Error: {str(e)}', 'danger')
            return redirect(url_for('admin.notificaciones'))
        finally:
            cursor.close()
    
    return render_template('admin/notificaciones.html')


# --- AUDITORÍA HISTORIAS ---
@admin_bp.route('/auditorias-historias')
@login_required
@role_required('admin')
def auditorias_historias():
    """Ver auditoría de historias clínicas"""
    cursor = g.mysql.connection.cursor()
    
    try:
        query = """
            SELECT ah.id, ah.accion, ah.descripcion, ah.fecha_hora, ah.ip_address,
                   u.nombre_completo as usuario_nombre,
                   up.nombre_completo as paciente_nombre,
                   ud.nombre_completo as doctor_nombre
            FROM auditoria_historias ah
            JOIN usuarios u ON ah.usuario_id = u.id
            JOIN pacientes p ON ah.paciente_id = p.id
            JOIN usuarios up ON p.usuario_id = up.id
            JOIN doctores d ON ah.doctor_id = d.id
            JOIN usuarios ud ON d.usuario_id = ud.id
            ORDER BY ah.fecha_hora DESC
            LIMIT 500
        """
        cursor.execute(query)
        auditorias = cursor.fetchall()
        
        return render_template('admin/auditorias_historias.html', auditorias=auditorias)
        
    except Exception as e:
        flash(f'Error: {str(e)}', 'danger')
        return redirect(url_for('admin.dashboard'))
    finally:
        cursor.close()


# --- EDITAR PERMISOS DE ROL ---
@admin_bp.route('/roles/<int:rol_id>/permisos', methods=['GET'])
@login_required
@role_required('admin')
def obtener_permisos_rol(rol_id):
    """Obtener permisos de un rol específico"""
    cursor = g.mysql.connection.cursor()
    
    try:
        # Obtener todos los permisos disponibles
        cursor.execute("SELECT id, nombre, descripcion, modulo FROM permisos ORDER BY modulo, nombre")
        todos_permisos = cursor.fetchall()
        
        # Obtener permisos actuales del rol
        cursor.execute("""
            SELECT permiso_id FROM rol_permisos WHERE rol_id = %s
        """, (rol_id,))
        permisos_actuales = [p[0] for p in cursor.fetchall()]
        
        from flask import jsonify
        return jsonify({
            'todos_permisos': [{'id': p[0], 'nombre': p[1], 'descripcion': p[2], 'modulo': p[3]} for p in todos_permisos],
            'permisos_actuales': permisos_actuales
        })
        
    except Exception as e:
        from flask import jsonify
        return jsonify({'error': str(e)}), 500
    finally:
        cursor.close()


@admin_bp.route('/roles/<int:rol_id>/permisos', methods=['POST'])
@login_required
@role_required('admin')
def actualizar_permisos_rol(rol_id):
    """Actualizar permisos de un rol"""
    cursor = g.mysql.connection.cursor()
    
    try:
        from flask import request, jsonify
        permisos_seleccionados = request.json.get('permisos', [])
        
        # Eliminar permisos actuales
        cursor.execute("DELETE FROM rol_permisos WHERE rol_id = %s", (rol_id,))
        
        # Insertar nuevos permisos
        for permiso_id in permisos_seleccionados:
            cursor.execute("""
                INSERT INTO rol_permisos (rol_id, permiso_id) VALUES (%s, %s)
            """, (rol_id, permiso_id))
        
        g.mysql.connection.commit()
        
        return jsonify({'success': True, 'message': 'Permisos actualizados correctamente'})
        
    except Exception as e:
        g.mysql.connection.rollback()
        from flask import jsonify
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        cursor.close()

# --- EXPORTAR REPORTES ---
@admin_bp.route('/reportes/exportar/<formato>')
@login_required
@role_required('admin')
def exportar_reporte(formato):
    """Exportar reportes en diferentes formatos"""
    cursor = g.mysql.connection.cursor()
    
    try:
        # Obtener datos
        cursor.execute("SELECT COUNT(*) FROM usuarios WHERE activo = TRUE")
        total_usuarios = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM usuarios WHERE rol_id = 2")
        total_doctores = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM usuarios WHERE rol_id = 1")
        total_pacientes = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM citas")
        total_citas = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM historias_clinicas")
        total_historias = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM recetas")
        total_recetas = cursor.fetchone()[0]
        
        # Datos detallados de usuarios
        cursor.execute("""
            SELECT u.id, u.nombre_completo, u.email, r.nombre as rol, 
                   IF(u.activo, 'Activo', 'Inactivo') as estado
            FROM usuarios u
            JOIN roles r ON u.rol_id = r.id
            ORDER BY u.id
        """)
        usuarios_detalle = cursor.fetchall()
        
        if formato == 'pdf':
            return exportar_pdf(total_usuarios, total_doctores, total_pacientes, 
                              total_citas, total_historias, total_recetas, usuarios_detalle)
        elif formato == 'excel':
            return exportar_excel(total_usuarios, total_doctores, total_pacientes, 
                                total_citas, total_historias, total_recetas, usuarios_detalle)
        elif formato == 'csv':
            return exportar_csv(usuarios_detalle)
        else:
            flash('Formato no válido', 'danger')
            return redirect(url_for('admin.ver_reportes'))
            
    except Exception as e:
        flash(f'Error al exportar: {str(e)}', 'danger')
        return redirect(url_for('admin.ver_reportes'))
    finally:
        cursor.close()


def exportar_pdf(total_usuarios, total_doctores, total_pacientes, total_citas, total_historias, total_recetas, usuarios):
    """Generar reporte en PDF"""
    from reportlab.lib.pagesizes import letter, A4
    from reportlab.lib import colors
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak
    from reportlab.lib.enums import TA_CENTER, TA_LEFT
    
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=30, leftMargin=30, topMargin=30, bottomMargin=18)
    
    elements = []
    styles = getSampleStyleSheet()
    
    # Título
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=24,
        textColor=colors.HexColor('#4cd1ff'),
        spaceAfter=30,
        alignment=TA_CENTER
    )
    
    title = Paragraph("Reporte de Estadísticas - Clínica Vital", title_style)
    elements.append(title)
    
    # Fecha
    fecha = Paragraph(f"Generado el: {datetime.now().strftime('%d/%m/%Y %H:%M')}", styles['Normal'])
    elements.append(fecha)
    elements.append(Spacer(1, 20))
    
    # Estadísticas generales
    subtitle = Paragraph("Estadísticas Generales", styles['Heading2'])
    elements.append(subtitle)
    elements.append(Spacer(1, 12))
    
    stats_data = [
        ['Métrica', 'Cantidad'],
        ['Usuarios Activos', str(total_usuarios)],
        ['Doctores', str(total_doctores)],
        ['Pacientes', str(total_pacientes)],
        ['Citas Totales', str(total_citas)],
        ['Historias Clínicas', str(total_historias)],
        ['Recetas Emitidas', str(total_recetas)]
    ]
    
    stats_table = Table(stats_data, colWidths=[3*inch, 2*inch])
    stats_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#4cd1ff')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 12),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    
    elements.append(stats_table)
    elements.append(Spacer(1, 30))
    
    # Listado de usuarios
    subtitle2 = Paragraph("Listado de Usuarios", styles['Heading2'])
    elements.append(subtitle2)
    elements.append(Spacer(1, 12))
    
    users_data = [['ID', 'Nombre', 'Email', 'Rol', 'Estado']]
    for user in usuarios[:20]:  # Limitar a 20 usuarios
        users_data.append([
            str(user[0]),
            user[1][:25],
            user[2][:30],
            user[3],
            user[4]
        ])
    
    users_table = Table(users_data, colWidths=[0.5*inch, 1.8*inch, 2*inch, 1*inch, 0.8*inch])
    users_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#4cd1ff')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 10),
        ('FONTSIZE', (0, 1), (-1, -1), 8),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    
    elements.append(users_table)
    
    doc.build(elements)
    buffer.seek(0)
    
    return send_file(
        buffer,
        as_attachment=True,
        download_name=f'reporte_clinica_{datetime.now().strftime("%Y%m%d_%H%M%S")}.pdf',
        mimetype='application/pdf'
    )


def exportar_excel(total_usuarios, total_doctores, total_pacientes, total_citas, total_historias, total_recetas, usuarios):
    """Generar reporte en Excel"""
    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment, PatternFill
    
    wb = Workbook()
    
    # Hoja 1: Estadísticas
    ws1 = wb.active
    ws1.title = "Estadísticas"
    
    # Título
    ws1['A1'] = "Reporte de Estadísticas - Clínica Vital"
    ws1['A1'].font = Font(size=16, bold=True, color="4cd1ff")
    ws1.merge_cells('A1:B1')
    
    ws1['A2'] = f"Generado: {datetime.now().strftime('%d/%m/%Y %H:%M')}"
    ws1.merge_cells('A2:B2')
    
    # Datos
    ws1['A4'] = "Métrica"
    ws1['B4'] = "Cantidad"
    ws1['A4'].font = Font(bold=True)
    ws1['B4'].font = Font(bold=True)
    ws1['A4'].fill = PatternFill(start_color="4cd1ff", end_color="4cd1ff", fill_type="solid")
    ws1['B4'].fill = PatternFill(start_color="4cd1ff", end_color="4cd1ff", fill_type="solid")
    
    datos = [
        ('Usuarios Activos', total_usuarios),
        ('Doctores', total_doctores),
        ('Pacientes', total_pacientes),
        ('Citas Totales', total_citas),
        ('Historias Clínicas', total_historias),
        ('Recetas Emitidas', total_recetas)
    ]
    
    for idx, (metrica, valor) in enumerate(datos, start=5):
        ws1[f'A{idx}'] = metrica
        ws1[f'B{idx}'] = valor
        ws1[f'B{idx}'].alignment = Alignment(horizontal='center')
    
    # Hoja 2: Usuarios
    ws2 = wb.create_sheet(title="Usuarios")
    
    headers = ['ID', 'Nombre Completo', 'Email', 'Rol', 'Estado']
    for col, header in enumerate(headers, start=1):
        cell = ws2.cell(row=1, column=col)
        cell.value = header
        cell.font = Font(bold=True)
        cell.fill = PatternFill(start_color="4cd1ff", end_color="4cd1ff", fill_type="solid")
        cell.alignment = Alignment(horizontal='center')
    
    for row_idx, user in enumerate(usuarios, start=2):
        for col_idx, value in enumerate(user, start=1):
            ws2.cell(row=row_idx, column=col_idx, value=value)
    
    # Ajustar anchos
    ws1.column_dimensions['A'].width = 25
    ws1.column_dimensions['B'].width = 15
    ws2.column_dimensions['A'].width = 8
    ws2.column_dimensions['B'].width = 30
    ws2.column_dimensions['C'].width = 35
    ws2.column_dimensions['D'].width = 15
    ws2.column_dimensions['E'].width = 12
    
    buffer = io.BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    
    return send_file(
        buffer,
        as_attachment=True,
        download_name=f'reporte_clinica_{datetime.now().strftime("%Y%m%d_%H%M%S")}.xlsx',
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )


def exportar_csv(usuarios):
    """Generar reporte en CSV"""
    output = io.StringIO()
    writer = csv.writer(output)
    
    # Encabezados
    writer.writerow(['ID', 'Nombre Completo', 'Email', 'Rol', 'Estado'])
    
    # Datos
    for user in usuarios:
        writer.writerow(user)
    
    output.seek(0)
    
    response = make_response(output.getvalue())
    response.headers['Content-Disposition'] = f'attachment; filename=reporte_usuarios_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
    response.headers['Content-Type'] = 'text/csv'
    
    return response


import subprocess
import os
from datetime import datetime

# --- RESPALDOS ---
import os
import subprocess
from datetime import datetime
from flask import render_template, redirect, url_for, flash, send_file, session
from utils.decorators import login_required, role_required
from utils.helpers import registrar_auditoria

# --- RESPALDOS ---
# --- RESPALDOS ---
@admin_bp.route('/respaldos')
@login_required
@role_required('admin')
def ver_respaldos():
    """Ver respaldos disponibles"""
    backup_dir = 'backups'
    if not os.path.exists(backup_dir):
        os.makedirs(backup_dir)
    
    backups = []
    for file in os.listdir(backup_dir):
        if file.endswith('.sql'):
            file_path = os.path.join(backup_dir, file)
            file_size = os.path.getsize(file_path)
            file_date = datetime.fromtimestamp(os.path.getmtime(file_path))
            backups.append({
                'nombre': file,
                'tamano': f"{file_size / 1024:.2f} KB",
                'fecha': file_date.strftime('%d/%m/%Y %H:%M:%S')
            })
    backups.sort(key=lambda x: x['fecha'], reverse=True)
    return render_template('admin/respaldos.html', backups=backups)


@admin_bp.route('/respaldos/crear', methods=['POST'])
@login_required
@role_required('admin')
def crear_respaldo():
    """Crear backup de la base de datos"""
    try:
        backup_dir = 'backups'
        if not os.path.exists(backup_dir):
            os.makedirs(backup_dir)

        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f'backup_clinica_{timestamp}.sql'
        filepath = os.path.abspath(os.path.join(backup_dir, filename))

        db_host = 'localhost'
        db_user = 'root'
        db_password = ''
        db_name = 'clinica_vital'
        mysqldump_path = r'C:\xampp\mysql\bin\mysqldump.exe'

        dump_cmd = [
            mysqldump_path,
            '-h', db_host,
            '-u', db_user,
            db_name,
            f'--result-file={filepath}'
        ]
        if db_password:
            dump_cmd.insert(4, f'--password={db_password}')

        result = subprocess.run(
            dump_cmd,
            capture_output=True,
            text=True,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        )

        if result.returncode != 0:
            raise Exception(result.stderr if result.stderr else 'Error desconocido')

        registrar_auditoria(
            usuario_id=session.get('user_id'),
            accion='Crear backup',
            modulo='respaldos',
            detalles=f'Backup creado: {filename}'
        )

        flash(f'✅ Backup creado: {filename}', 'success')
    except FileNotFoundError:
        flash('❌ mysqldump.exe no encontrado', 'danger')
    except Exception as e:
        flash(f'❌ Error: {str(e)}', 'danger')
    return redirect(url_for('admin.ver_respaldos'))


@admin_bp.route('/respaldos/descargar/<filename>')
@login_required
@role_required('admin')
def descargar_respaldo(filename):
    """Descargar archivo de backup"""
    try:
        backup_dir = 'backups'
        filepath = os.path.join(backup_dir, filename)
        if not os.path.exists(filepath):
            flash('Archivo no encontrado', 'danger')
            return redirect(url_for('admin.ver_respaldos'))

        registrar_auditoria(
            usuario_id=session.get('user_id'),
            accion='Descargar backup',
            modulo='respaldos',
            detalles=f'Backup descargado: {filename}'
        )
        return send_file(filepath, as_attachment=True, download_name=filename)
    except Exception as e:
        flash(f'Error: {str(e)}', 'danger')
        return redirect(url_for('admin.ver_respaldos'))


@admin_bp.route('/respaldos/eliminar/<filename>', methods=['POST'])
@login_required
@role_required('admin')
def eliminar_respaldo(filename):
    """Eliminar archivo de backup"""
    try:
        backup_dir = 'backups'
        filepath = os.path.join(backup_dir, filename)
        if os.path.exists(filepath):
            os.remove(filepath)
            registrar_auditoria(
                usuario_id=session.get('user_id'),
                accion='Eliminar backup',
                modulo='respaldos',
                detalles=f'Backup eliminado: {filename}'
            )
            flash('✅ Backup eliminado', 'success')
        else:
            flash('Archivo no encontrado', 'danger')
    except Exception as e:
        flash(f'Error: {str(e)}', 'danger')
    return redirect(url_for('admin.ver_respaldos'))


@admin_bp.route('/respaldos/restaurar/<filename>', methods=['POST'])
@login_required
@role_required('admin')
def restaurar_respaldo(filename):
    """Restaurar base de datos desde backup"""
    try:
        backup_dir = 'backups'
        filepath = os.path.abspath(os.path.join(backup_dir, filename))
        if not os.path.exists(filepath):
            flash('Archivo no encontrado', 'danger')
            return redirect(url_for('admin.ver_respaldos'))

        db_host = 'localhost'
        db_user = 'root'
        db_password = ''
        db_name = 'clinica_vital'
        mysql_path = r'C:\xampp\mysql\bin\mysql.exe'

        restore_cmd = [
            mysql_path,
            '-h', db_host,
            '-u', db_user,
            db_name
        ]
        if db_password:
            restore_cmd.insert(4, f'--password={db_password}')

        with open(filepath, 'r', encoding='utf-8') as f:
            result = subprocess.run(
                restore_cmd,
                stdin=f,
                capture_output=True,
                text=True,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
            )

        if result.returncode != 0:
            raise Exception(result.stderr if result.stderr else 'Error desconocido')

        registrar_auditoria(
            usuario_id=session.get('user_id'),
            accion='Restaurar backup',
            modulo='respaldos',
            detalles=f'Backup restaurado: {filename}'
        )

        flash(f'✅ Base de datos restaurada: {filename}', 'success')
    except FileNotFoundError:
        flash('❌ mysql.exe no encontrado', 'danger')
    except Exception as e:
        flash(f'❌ Error: {str(e)}', 'danger')
    return redirect(url_for('admin.ver_respaldos'))

#CAmbiar ROLES..

@admin_bp.route('/usuario/<int:usuario_id>/cambiar-rol', methods=['POST'])
@login_required
@role_required('admin')
def cambiar_rol_usuario(usuario_id):
    """Cambiar rol de un usuario"""
    cursor = g.mysql.connection.cursor()
    
    try:
        nuevo_rol_id = request.form.get('rol_id')
        
        if not nuevo_rol_id:
            flash('Debes seleccionar un rol', 'danger')
            return redirect(url_for('admin.ver_usuarios'))
        
        # Obtener datos del usuario
        cursor.execute("SELECT nombre_completo FROM usuarios WHERE id = %s", (usuario_id,))
        usuario = cursor.fetchone()
        
        if not usuario:
            flash('Usuario no encontrado', 'danger')
            return redirect(url_for('admin.ver_usuarios'))
        
        # Actualizar rol
        cursor.execute("UPDATE usuarios SET rol_id = %s WHERE id = %s", (nuevo_rol_id, usuario_id))
        g.mysql.connection.commit()
        
        registrar_auditoria(
            usuario_id=session.get('user_id'),
            accion='Cambiar rol',
            modulo='usuarios',
            detalles=f'Cambio de rol para: {usuario[0]} (rol_id: {nuevo_rol_id})',
            registro_id=usuario_id
        )
        
        flash(f'✅ Rol actualizado para {usuario[0]}', 'success')
        
    except Exception as e:
        g.mysql.connection.rollback()
        flash(f'❌ Error: {str(e)}', 'danger')
    finally:
        cursor.close()
    
    return redirect(url_for('admin.ver_usuarios'))
