from flask import Blueprint, render_template, request, redirect, url_for, session, flash, g
from werkzeug.security import generate_password_hash, check_password_hash
from utils.helpers import registrar_auditoria
from utils.decorators import login_required
from datetime import datetime


auth_bp = Blueprint('auth', __name__)


# =====================================
# LOGIN
# =====================================
@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        print(f"\n{'='*50}")
        print(f"DEBUG: Intentando login")
        print(f"DEBUG: Username: {username}")
        print(f"DEBUG: Password: {password}")

        cursor = g.mysql.connection.cursor()
        query = """
            SELECT u.id, u.username, u.password, u.rol_id, u.nombre_completo, r.nombre as rol
            FROM usuarios u
            JOIN roles r ON u.rol_id = r.id
            WHERE u.username = %s AND u.activo = TRUE
        """
        cursor.execute(query, (username,))
        user = cursor.fetchone()
        
        print(f"DEBUG: Usuario encontrado: {user is not None}")
        if user:
            print(f"DEBUG: ID: {user[0]}, Username: {user[1]}, Rol: {user[5]}")
            print(f"DEBUG: Hash guardado: {user[2][:30]}...")
            
            password_valida = check_password_hash(user[2], password)
            print(f"DEBUG: Contraseña válida: {password_valida}")
        else:
            print(f"DEBUG: No se encontró usuario con username: {username}")
        
        cursor.close()

        if user and check_password_hash(user[2], password):
            print(f"DEBUG: Guardando sesión...")
            session['usuario_id'] = user[0]
            session['username'] = user[1]
            session['rol_id'] = user[3]
            session['nombre_completo'] = user[4]
            session['rol'] = user[5]
            
            session.modified = True
            
            print(f"DEBUG: Sesión después de guardar: {dict(session)}")
            print(f"DEBUG: usuario_id en sesión: {session.get('usuario_id')}")
            print(f"DEBUG: rol en sesión: {session.get('rol')}")
            
            registrar_auditoria(user[0], 'login', 'sistema')
            flash(f'¡Bienvenido {user[4]}!', 'success')
            
            print(f"DEBUG: Redirigiendo a paciente.dashboard")
            print(f"{'='*50}\n")
            return redirect(url_for('paciente.dashboard'))
        else:
            print(f"DEBUG: Autenticación fallida")
            print(f"{'='*50}\n")
            flash('Usuario o contraseña incorrectos', 'danger')
            return redirect(url_for('auth.login'))
    
    return render_template('login.html')


# =====================================
# REGISTRO
# =====================================
@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        nombre_completo = request.form.get('nombre_completo', username)
        
        rol_id = 4  # Paciente
        password_hash = generate_password_hash(password)

        cursor = g.mysql.connection.cursor()
        cursor.execute("SELECT id FROM usuarios WHERE username = %s OR email = %s", (username, email))
        if cursor.fetchone():
            cursor.close()
            flash('El usuario o email ya existe', 'warning')
            return redirect(url_for('auth.login'))

        try:
            query = """
                INSERT INTO usuarios (username, email, password, rol_id, nombre_completo)
                VALUES (%s, %s, %s, %s, %s)
            """
            cursor.execute(query, (username, email, password_hash, rol_id, nombre_completo))
            g.mysql.connection.commit()
            usuario_id = cursor.lastrowid

            cursor.execute("INSERT INTO pacientes (usuario_id) VALUES (%s)", (usuario_id,))
            g.mysql.connection.commit()
            cursor.close()

            flash('Registro exitoso. Por favor inicia sesión', 'success')
            return redirect(url_for('auth.login'))
        except Exception as e:
            g.mysql.connection.rollback()
            cursor.close()
            flash(f'Error al registrar: {str(e)}', 'danger')
            return redirect(url_for('auth.login'))
    
    return render_template('login.html')


# =====================================
# LOGOUT
# =====================================
@auth_bp.route('/logout')
@login_required
def logout():
    registrar_auditoria(session['usuario_id'], 'logout', 'sistema')
    session.clear()
    flash('Has cerrado sesión exitosamente', 'info')
    return redirect(url_for('auth.login'))
