from flask import Blueprint, render_template, request, redirect, url_for, flash, session, g, make_response, jsonify
from utils.decorators import login_required, role_required, permission_required
from utils.helpers import registrar_auditoria
from datetime import datetime
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from io import BytesIO
from werkzeug.security import check_password_hash, generate_password_hash 
import os

paciente_bp = Blueprint('paciente', __name__)


# =====================================
# DASHBOARD
# =====================================
@paciente_bp.route('/dashboard')
@login_required
@role_required('paciente')
def dashboard():
    cursor = g.mysql.connection.cursor()
    
    try:
        cursor.execute("SELECT id FROM pacientes WHERE usuario_id = %s", (session['usuario_id'],))
        paciente = cursor.fetchone()
        
        if not paciente:
            flash('No se encontró información del paciente', 'danger')
            return redirect(url_for('auth.login'))
        
        paciente_id = paciente[0]
        
        query = """
            SELECT c.*, u.nombre_completo as doctor_nombre, e.nombre as especialidad
            FROM citas c
            JOIN doctores d ON c.doctor_id = d.id
            JOIN usuarios u ON d.usuario_id = u.id
            JOIN especialidades e ON d.especialidad_id = e.id
            WHERE c.paciente_id = %s AND c.fecha_hora >= NOW()
            ORDER BY c.fecha_hora
            LIMIT 5
        """
        cursor.execute(query, (paciente_id,))
        citas = cursor.fetchall()
        
        return render_template('paciente/dashboard.html', citas=citas)
        
    except Exception as e:
        flash(f'Error al cargar el dashboard: {str(e)}', 'danger')
        return redirect(url_for('auth.login'))
    finally:
        cursor.close()


# =====================================
# PERFIL
# =====================================
@paciente_bp.route('/mi-perfil')
@login_required
@role_required('paciente')
def mi_perfil():
    cursor = g.mysql.connection.cursor()
    
    try:
        query = """
            SELECT p.id, p.usuario_id, p.tipo_sangre, p.alergias, 
                   p.enfermedades_cronicas, p.contacto_emergencia, p.telefono_emergencia,
                   u.nombre_completo, u.email, u.telefono, u.activo,
                   u.cedula, u.fecha_nacimiento, u.genero, u.direccion
            FROM pacientes p
            JOIN usuarios u ON p.usuario_id = u.id
            WHERE p.usuario_id = %s
        """
        cursor.execute(query, (session['usuario_id'],))
        paciente = cursor.fetchone()
        
        if not paciente:
            flash('No se encontró información del paciente', 'danger')
            return redirect(url_for('paciente.dashboard'))
        
        return render_template('paciente/mi_perfil.html', paciente=paciente)
        
    except Exception as e:
        flash(f'Error al cargar el perfil: {str(e)}', 'danger')
        return redirect(url_for('paciente.dashboard'))
    finally:
        cursor.close()


@paciente_bp.route('/mi-perfil/editar', methods=['GET', 'POST'])
@login_required
@role_required('paciente')
def editar_perfil():
    cursor = g.mysql.connection.cursor()
    
    try:
        if request.method == 'POST':
            # AHORA INCLUYE EMAIL Y CEDULA
            email = request.form.get('email')
            cedula = request.form.get('cedula')
            telefono = request.form.get('telefono')
            direccion = request.form.get('direccion')
            tipo_sangre = request.form.get('tipo_sangre')
            alergias = request.form.get('alergias')
            enfermedades_cronicas = request.form.get('enfermedades_cronicas')
            contacto_emergencia = request.form.get('contacto_emergencia_nombre')
            telefono_emergencia = request.form.get('contacto_emergencia_telefono')
            
            try:
                cursor.execute("""
                    UPDATE usuarios 
                    SET email = COALESCE(%s, email),
                        cedula = COALESCE(%s, cedula),
                        telefono = COALESCE(%s, telefono),
                        direccion = COALESCE(%s, direccion)
                    WHERE id = %s
                """, (email if email else None,
                      cedula if cedula else None,
                      telefono if telefono else None,
                      direccion if direccion else None,
                      session['usuario_id']))
                
                cursor.execute("""
                    UPDATE pacientes 
                    SET tipo_sangre = %s, alergias = %s, enfermedades_cronicas = %s,
                        contacto_emergencia = %s, telefono_emergencia = %s
                    WHERE usuario_id = %s
                """, (tipo_sangre, alergias, enfermedades_cronicas, 
                      contacto_emergencia, telefono_emergencia, session['usuario_id']))
                
                g.mysql.connection.commit()
                
                registrar_auditoria(
                    usuario_id=session['usuario_id'],
                    accion='actualizar_perfil',
                    modulo='pacientes',
                    detalles='Perfil actualizado'
                )
                
                flash('✅ Perfil actualizado exitosamente', 'success')
                return redirect(url_for('paciente.mi_perfil'))
                
            except Exception as e:
                g.mysql.connection.rollback()
                if 'Duplicate' in str(e) or 'duplicate' in str(e).lower():
                    flash('❌ El correo o la cédula ya están en uso', 'danger')
                else:
                    flash(f'❌ Error al actualizar: {str(e)}', 'danger')
                return redirect(url_for('paciente.editar_perfil'))
        
        query = """
            SELECT p.id, p.usuario_id, p.tipo_sangre, p.alergias, 
                   p.enfermedades_cronicas, p.contacto_emergencia, p.telefono_emergencia,
                   u.nombre_completo, u.email, u.telefono, u.activo,
                   u.cedula, u.fecha_nacimiento, u.genero, u.direccion
            FROM pacientes p
            JOIN usuarios u ON p.usuario_id = u.id
            WHERE p.usuario_id = %s
        """
        cursor.execute(query, (session['usuario_id'],))
        paciente = cursor.fetchone()
        
        if not paciente:
            flash('No se encontró información del paciente', 'danger')
            return redirect(url_for('paciente.dashboard'))
        
        return render_template('paciente/editar_perfil.html', paciente=paciente)
        
    except Exception as e:
        g.mysql.connection.rollback()
        flash(f'Error al editar el perfil: {str(e)}', 'danger')
        return redirect(url_for('paciente.mi_perfil'))
    finally:
        cursor.close()



# =====================================
# HISTORIAS CLÍNICAS
# =====================================
@paciente_bp.route('/mi-historia-clinica')
@login_required
@role_required('paciente')
def mi_historia_clinica():
    cursor = g.mysql.connection.cursor()
    
    try:
        cursor.execute("SELECT id FROM pacientes WHERE usuario_id = %s", (session['usuario_id'],))
        paciente = cursor.fetchone()
        
        if not paciente:
            flash('No se encontró información del paciente', 'danger')
            return redirect(url_for('paciente.dashboard'))
        
        paciente_id = paciente[0]
        
        registrar_auditoria(
            usuario_id=session['usuario_id'],
            accion='ver_historia_clinica',
            modulo='historias_clinicas',
            detalles=f'Paciente consultó sus historias clínicas'
        )
        
        query = """
            SELECT hc.id, hc.paciente_id, hc.doctor_id, hc.fecha_consulta,
                   hc.motivo_consulta, hc.sintomas, hc.diagnostico, hc.observaciones,
                   hc.presion_arterial, hc.temperatura, hc.peso, hc.altura, 
                   hc.tratamiento, hc.fecha_creacion, hc.usuario_id,
                   u.nombre_completo as doctor_nombre, e.nombre as especialidad
            FROM historias_clinicas hc
            JOIN doctores d ON hc.doctor_id = d.id
            JOIN usuarios u ON d.usuario_id = u.id
            JOIN especialidades e ON d.especialidad_id = e.id
            WHERE hc.paciente_id = %s
            ORDER BY hc.fecha_consulta DESC
        """
        cursor.execute(query, (paciente_id,))
        historias = cursor.fetchall()
        
        return render_template('paciente/mi_historia_clinica.html', historias=historias)
        
    except Exception as e:
        flash(f'Error al cargar historias clínicas: {str(e)}', 'danger')
        return redirect(url_for('paciente.dashboard'))
    finally:
        cursor.close()


@paciente_bp.route('/historia/<int:historia_id>')
@login_required
@role_required('paciente')
def ver_historia(historia_id):
    cursor = g.mysql.connection.cursor()
    
    try:
        cursor.execute("SELECT id FROM pacientes WHERE usuario_id = %s", (session['usuario_id'],))
        paciente = cursor.fetchone()
        
        if not paciente:
            flash('No se encontró información del paciente', 'danger')
            return redirect(url_for('paciente.dashboard'))
        
        paciente_id = paciente[0]
        
        query = """
            SELECT hc.id, hc.paciente_id, hc.doctor_id, hc.fecha_consulta,
                   hc.motivo_consulta, hc.sintomas, hc.diagnostico, hc.observaciones,
                   hc.presion_arterial, hc.temperatura, hc.peso, hc.altura, 
                   hc.tratamiento, hc.fecha_creacion, hc.usuario_id,
                   u.nombre_completo as doctor_nombre, e.nombre as especialidad
            FROM historias_clinicas hc
            JOIN doctores d ON hc.doctor_id = d.id
            JOIN usuarios u ON d.usuario_id = u.id
            JOIN especialidades e ON d.especialidad_id = e.id
            WHERE hc.id = %s AND hc.paciente_id = %s
        """
        cursor.execute(query, (historia_id, paciente_id))
        historia = cursor.fetchone()
        
        if not historia:
            flash('Historia clínica no encontrada', 'danger')
            return redirect(url_for('paciente.mi_historia_clinica'))
        
        registrar_auditoria(
            usuario_id=session['usuario_id'],
            accion='ver_detalle_historia',
            modulo='historias_clinicas',
            registro_id=historia_id,
            detalles=f'Paciente consultó detalles de historia clínica ID {historia_id}'
        )
        
        return render_template('paciente/ver_historia.html', historia=historia)
        
    except Exception as e:
        flash(f'Error al cargar la historia: {str(e)}', 'danger')
        return redirect(url_for('paciente.mi_historia_clinica'))
    finally:
        cursor.close()


@paciente_bp.route('/historia/<int:historia_id>/pdf')
@login_required
@role_required('paciente')
def descargar_historia_pdf(historia_id):
    """Descargar historia clínica en PDF con firma del doctor"""
    cursor = g.mysql.connection.cursor()
    
    try:
        cursor.execute("SELECT id FROM pacientes WHERE usuario_id = %s", (session['usuario_id'],))
        paciente = cursor.fetchone()
        
        if not paciente:
            flash('No se encontró información del paciente', 'danger')
            return redirect(url_for('paciente.dashboard'))
        
        paciente_id = paciente[0]
        
        query = """
            SELECT hc.id, hc.paciente_id, hc.doctor_id, hc.fecha_consulta,
                   hc.motivo_consulta, hc.sintomas, hc.diagnostico, hc.observaciones,
                   hc.presion_arterial, hc.temperatura, hc.peso, hc.altura, 
                   hc.tratamiento, hc.fecha_creacion, hc.usuario_id,
                   u.nombre_completo as doctor_nombre, e.nombre as especialidad,
                   up.nombre_completo as paciente_nombre, up.cedula, up.email, up.telefono,
                   d.firma_path
            FROM historias_clinicas hc
            JOIN doctores d ON hc.doctor_id = d.id
            JOIN usuarios u ON d.usuario_id = u.id
            JOIN especialidades e ON d.especialidad_id = e.id
            JOIN pacientes p ON hc.paciente_id = p.id
            JOIN usuarios up ON p.usuario_id = up.id
            WHERE hc.id = %s AND hc.paciente_id = %s
        """
        cursor.execute(query, (historia_id, paciente_id))
        h = cursor.fetchone()
        
        if not h:
            flash('Historia clínica no encontrada', 'danger')
            return redirect(url_for('paciente.mi_historia_clinica'))
        
        pdf_buffer = BytesIO()
        doc = SimpleDocTemplate(pdf_buffer, pagesize=A4, topMargin=0.5*inch, bottomMargin=0.5*inch)
        story = []
        styles = getSampleStyleSheet()
        
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=18,
            textColor=colors.HexColor('#1a3a52'),
            spaceAfter=6,
            alignment=TA_CENTER,
            fontName='Helvetica-Bold'
        )
        
        subtitle_style = ParagraphStyle(
            'Subtitle',
            parent=styles['Normal'],
            fontSize=10,
            textColor=colors.HexColor('#666666'),
            alignment=TA_CENTER,
            spaceAfter=20
        )
        
        section_style = ParagraphStyle(
            'SectionTitle',
            parent=styles['Heading2'],
            fontSize=12,
            textColor=colors.white,
            backColor=colors.HexColor('#4cd1ff'),
            spaceAfter=10,
            spaceBefore=10,
            fontName='Helvetica-Bold',
            leftIndent=5
        )
        
        story.append(Paragraph("CLÍNICA VITAL", title_style))
        story.append(Paragraph("Ibagué, Tolima | Tel: (8) 123-4567", subtitle_style))
        story.append(Paragraph("_" * 80, styles['Normal']))
        story.append(Spacer(1, 0.15*inch))
        
        story.append(Paragraph("HISTORIA CLÍNICA ELECTRÓNICA", title_style))
        story.append(Paragraph(f"Fecha de Impresión: {datetime.now().strftime('%d/%m/%Y %H:%M')}", subtitle_style))
        story.append(Spacer(1, 0.2*inch))
        
        story.append(Paragraph("INFORMACIÓN DEL PACIENTE", section_style))
        patient_data = [
            ['Paciente', h[17], 'Cédula', h[18]],
            ['Email', h[19] if h[19] else 'N/A', 'Teléfono', h[20] if h[20] else 'N/A'],
        ]
        patient_table = Table(patient_data, colWidths=[1.5*inch, 1.8*inch, 1.5*inch, 1.8*inch])
        patient_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#e8f4f8')),
            ('BACKGROUND', (2, 0), (2, -1), colors.HexColor('#e8f4f8')),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.HexColor('#1a3a52')),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('LEFTPADDING', (0, 0), (-1, -1), 8),
            ('RIGHTPADDING', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#cccccc')),
        ]))
        story.append(patient_table)
        story.append(Spacer(1, 0.2*inch))
        
        story.append(Paragraph("Motivo de Consulta", styles['Heading3']))
        story.append(Paragraph(h[4] if h[4] else 'N/A', styles['Normal']))
        story.append(Spacer(1, 0.1*inch))
        
        story.append(Paragraph("Síntomas Reportados", styles['Heading3']))
        story.append(Paragraph(h[5] if h[5] else 'N/A', styles['Normal']))
        story.append(Spacer(1, 0.15*inch))
        
        story.append(Paragraph("SIGNOS VITALES", section_style))
        vitals_data = [
            ['Presión Arterial', h[8] if h[8] else 'N/A', 'Temperatura', f"{h[9]}°C" if h[9] else 'N/A'],
            ['Peso', f"{h[10]} kg" if h[10] else 'N/A', 'Altura', f"{h[11]} cm" if h[11] else 'N/A'],
        ]
        vitals_table = Table(vitals_data, colWidths=[1.5*inch, 1.8*inch, 1.5*inch, 1.8*inch])
        vitals_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#e8f4f8')),
            ('BACKGROUND', (2, 0), (2, -1), colors.HexColor('#e8f4f8')),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.HexColor('#1a3a52')),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('LEFTPADDING', (0, 0), (-1, -1), 8),
            ('RIGHTPADDING', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#cccccc')),
        ]))
        story.append(vitals_table)
        story.append(Spacer(1, 0.15*inch))
        
        story.append(Paragraph("DIAGNÓSTICO", section_style))
        story.append(Paragraph(h[6] if h[6] else 'N/A', styles['Normal']))
        story.append(Spacer(1, 0.15*inch))
        
        if h[7]:
            story.append(Paragraph("OBSERVACIONES", section_style))
            story.append(Paragraph(h[7], styles['Normal']))
            story.append(Spacer(1, 0.15*inch))
        
        if h[12]:
            story.append(Paragraph("TRATAMIENTO", section_style))
            story.append(Paragraph(h[12], styles['Normal']))
            story.append(Spacer(1, 0.15*inch))
        
        story.append(Paragraph("MÉDICO TRATANTE", section_style))
        doctor_data = [
            ['Doctor', f"Dr(a). {h[15]}", 'Especialidad', h[16]],
        ]
        doctor_table = Table(doctor_data, colWidths=[1.5*inch, 1.8*inch, 1.5*inch, 1.8*inch])
        doctor_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#e8f4f8')),
            ('BACKGROUND', (2, 0), (2, -1), colors.HexColor('#e8f4f8')),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.HexColor('#1a3a52')),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('LEFTPADDING', (0, 0), (-1, -1), 8),
            ('RIGHTPADDING', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#cccccc')),
        ]))
        story.append(doctor_table)
        story.append(Spacer(1, 0.3*inch))
        
        story.append(Paragraph("_" * 80, styles['Normal']))
        story.append(Spacer(1, 0.15*inch))
        
        if h[21]:
            firma_full_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', h[21])
            if os.path.exists(firma_full_path):
                try:
                    img = Image(firma_full_path, width=120, height=50)
                    story.append(img)
                    story.append(Spacer(1, 0.05*inch))
                except:
                    pass
        
        story.append(Paragraph(f"<b>Dr(a). {h[15]}</b>", ParagraphStyle('Center', parent=styles['Normal'], alignment=TA_CENTER)))
        story.append(Paragraph(f"Cédula: {h[18]}", ParagraphStyle('Center', parent=styles['Normal'], alignment=TA_CENTER, fontSize=9)))
        
        story.append(Spacer(1, 0.2*inch))
        story.append(Paragraph(
            "Este documento es confidencial y está protegido por las leyes de privacidad médica.<br/>"
            "Clínica Vital © 2025 - Todos los derechos reservados<br/>"
            f"Generado: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}<br/>"
            f"Documento ID: HC-{historia_id}",
            ParagraphStyle('Footer', parent=styles['Normal'], fontSize=8, textColor=colors.grey, alignment=TA_CENTER)
        ))
        
        doc.build(story)
        pdf_buffer.seek(0)
        
        response = make_response(pdf_buffer.getvalue())
        response.headers['Content-Type'] = 'application/pdf'
        response.headers['Content-Disposition'] = f'attachment; filename=HistoriaClinica_{h[18]}_{historia_id}.pdf'
        response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
        
        return response
        
    except Exception as e:
        flash(f'Error al generar PDF: {str(e)}', 'danger')
        return redirect(url_for('paciente.ver_historia', historia_id=historia_id))
    finally:
        cursor.close()


# =====================================
# RECETAS
# =====================================
@paciente_bp.route('/mis-recetas')
@login_required
@role_required('paciente')
def mis_recetas():
    cursor = g.mysql.connection.cursor()
    
    try:
        cursor.execute("SELECT id FROM pacientes WHERE usuario_id = %s", (session['usuario_id'],))
        paciente = cursor.fetchone()
        
        if not paciente:
            flash('No se encontró información del paciente', 'danger')
            return redirect(url_for('paciente.dashboard'))
        
        paciente_id = paciente[0]
        
        query = """
            SELECT 
                r.id, r.paciente_id, r.doctor_id, r.fecha_emision,
                r.diagnostico, r.medicamentos, r.dosis, r.frecuencia,
                r.duracion, r.indicaciones, r.activa,
                u.nombre_completo as doctor_nombre, 
                e.nombre as especialidad
            FROM recetas r
            JOIN doctores d ON r.doctor_id = d.id
            JOIN usuarios u ON d.usuario_id = u.id
            JOIN especialidades e ON d.especialidad_id = e.id
            WHERE r.paciente_id = %s AND r.activa = TRUE
            ORDER BY r.fecha_emision DESC
        """
        cursor.execute(query, (paciente_id,))
        recetas = cursor.fetchall()
        
        return render_template('paciente/mis_recetas.html', recetas=recetas)
        
    except Exception as e:
        flash(f'Error al cargar las recetas: {str(e)}', 'danger')
        return redirect(url_for('paciente.dashboard'))
    finally:
        cursor.close()


@paciente_bp.route('/receta/<int:receta_id>')
@login_required
@role_required('paciente')
def ver_receta(receta_id):
    """Ver detalle de una receta"""
    cursor = g.mysql.connection.cursor()
    
    try:
        cursor.execute("SELECT id FROM pacientes WHERE usuario_id = %s", (session['usuario_id'],))
        paciente = cursor.fetchone()
        
        if not paciente:
            flash('No se encontró información del paciente', 'danger')
            return redirect(url_for('paciente.dashboard'))
        
        paciente_id = paciente[0]
        
        query = """
            SELECT 
                r.id, r.paciente_id, r.doctor_id, r.fecha_emision,
                r.diagnostico, r.medicamentos, r.dosis, r.frecuencia,
                r.duracion, r.indicaciones, r.activa,
                u.nombre_completo as doctor_nombre, 
                e.nombre as especialidad,
                up.nombre_completo as paciente_nombre, 
                up.cedula
            FROM recetas r
            JOIN doctores d ON r.doctor_id = d.id
            JOIN usuarios u ON d.usuario_id = u.id
            JOIN especialidades e ON d.especialidad_id = e.id
            JOIN pacientes p ON r.paciente_id = p.id
            JOIN usuarios up ON p.usuario_id = up.id
            WHERE r.id = %s AND r.paciente_id = %s
        """
        cursor.execute(query, (receta_id, paciente_id))
        receta = cursor.fetchone()
        
        if not receta:
            flash('Receta no encontrada', 'danger')
            return redirect(url_for('paciente.mis_recetas'))
        
        return render_template('paciente/ver_receta.html', receta=receta)
        
    except Exception as e:
        flash(f'Error al cargar la receta: {str(e)}', 'danger')
        return redirect(url_for('paciente.mis_recetas'))
    finally:
        cursor.close()


@paciente_bp.route('/receta/<int:receta_id>/pdf')
@login_required
@role_required('paciente')
def descargar_receta_pdf(receta_id):
    """Descargar receta en PDF con firma del doctor"""
    cursor = g.mysql.connection.cursor()
    
    try:
        cursor.execute("SELECT id FROM pacientes WHERE usuario_id = %s", (session['usuario_id'],))
        paciente = cursor.fetchone()
        
        if not paciente:
            flash('No se encontró información del paciente', 'danger')
            return redirect(url_for('paciente.dashboard'))
        
        paciente_id = paciente[0]
        
        query = """
            SELECT 
                r.id, r.paciente_id, r.doctor_id, r.fecha_emision,
                r.diagnostico, r.medicamentos, r.dosis, r.frecuencia,
                r.duracion, r.indicaciones, r.activa,
                u.nombre_completo as doctor_nombre, 
                e.nombre as especialidad,
                up.nombre_completo as paciente_nombre, 
                up.cedula, up.email, up.telefono, up.direccion,
                d.licencia_medica, d.firma_path
            FROM recetas r
            JOIN doctores d ON r.doctor_id = d.id
            JOIN usuarios u ON d.usuario_id = u.id
            JOIN especialidades e ON d.especialidad_id = e.id
            JOIN pacientes p ON r.paciente_id = p.id
            JOIN usuarios up ON p.usuario_id = up.id
            WHERE r.id = %s AND r.paciente_id = %s
        """
        cursor.execute(query, (receta_id, paciente_id))
        r = cursor.fetchone()
        
        if not r:
            flash('Receta no encontrada', 'danger')
            return redirect(url_for('paciente.mis_recetas'))
        
        pdf_buffer = BytesIO()
        doc = SimpleDocTemplate(pdf_buffer, pagesize=A4, topMargin=0.5*inch, bottomMargin=0.5*inch)
        story = []
        styles = getSampleStyleSheet()
        
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=18,
            textColor=colors.HexColor('#1a3a52'),
            spaceAfter=6,
            alignment=TA_CENTER,
            fontName='Helvetica-Bold'
        )
        
        subtitle_style = ParagraphStyle(
            'Subtitle',
            parent=styles['Normal'],
            fontSize=10,
            textColor=colors.HexColor('#666666'),
            alignment=TA_CENTER,
            spaceAfter=20
        )
        
        section_style = ParagraphStyle(
            'SectionTitle',
            parent=styles['Heading2'],
            fontSize=12,
            textColor=colors.white,
            backColor=colors.HexColor('#4cd1ff'),
            spaceAfter=10,
            spaceBefore=10,
            fontName='Helvetica-Bold',
            leftIndent=5
        )
        
        story.append(Paragraph("CLÍNICA VITAL", title_style))
        story.append(Paragraph("Ibagué, Tolima | Tel: (8) 123-4567", subtitle_style))
        story.append(Paragraph("_" * 80, styles['Normal']))
        story.append(Spacer(1, 0.15*inch))
        
        story.append(Paragraph("RECETA MÉDICA", title_style))
        story.append(Paragraph(f"Fecha: {datetime.now().strftime('%d/%m/%Y %H:%M')}", subtitle_style))
        story.append(Spacer(1, 0.2*inch))
        
        story.append(Paragraph("INFORMACIÓN DEL PACIENTE", section_style))
        patient_data = [
            ['Paciente', r[13], 'Cédula', r[14]],
            ['Email', r[15] if r[15] else 'N/A', 'Teléfono', r[16] if r[16] else 'N/A'],
            ['Dirección', r[17] if r[17] else 'N/A', 'Fecha Receta', str(r[3])],
        ]
        patient_table = Table(patient_data, colWidths=[1.5*inch, 1.8*inch, 1.5*inch, 1.8*inch])
        patient_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#e8f4f8')),
            ('BACKGROUND', (2, 0), (2, -1), colors.HexColor('#e8f4f8')),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.HexColor('#1a3a52')),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('LEFTPADDING', (0, 0), (-1, -1), 8),
            ('RIGHTPADDING', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#cccccc')),
        ]))
        story.append(patient_table)
        story.append(Spacer(1, 0.2*inch))
        
        story.append(Paragraph("DIAGNÓSTICO", section_style))
        story.append(Paragraph(r[4] if r[4] else 'No especificado', styles['Normal']))
        story.append(Spacer(1, 0.15*inch))
        
        story.append(Paragraph("MEDICAMENTOS PRESCRITOS", section_style))
        
        meds_data = [
            ['Medicamentos', r[5] if r[5] else 'N/A'],
            ['Dosis', r[6] if r[6] else 'N/A'],
            ['Frecuencia', r[7] if r[7] else 'N/A'],
            ['Duración', r[8] if r[8] else 'N/A'],
        ]
        meds_table = Table(meds_data, colWidths=[1.5*inch, 4.5*inch])
        meds_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#e8f4f8')),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.HexColor('#1a3a52')),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('LEFTPADDING', (0, 0), (-1, -1), 8),
            ('RIGHTPADDING', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#cccccc')),
        ]))
        story.append(meds_table)
        story.append(Spacer(1, 0.15*inch))
        
        if r[9]:
            story.append(Paragraph("INDICACIONES ESPECIALES", section_style))
            story.append(Paragraph(r[9], styles['Normal']))
            story.append(Spacer(1, 0.15*inch))
        
        story.append(Paragraph("MÉDICO PRESCRIPTOR", section_style))
        story.append(Spacer(1, 0.15*inch))
        
        if r[19]:
            firma_full_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', r[19])
            if os.path.exists(firma_full_path):
                try:
                    img = Image(firma_full_path, width=120, height=50)
                    story.append(img)
                    story.append(Spacer(1, 0.08*inch))
                except:
                    pass
        
        story.append(Paragraph(f"<b>Dr(a). {r[11]}</b>", ParagraphStyle('Center', parent=styles['Normal'], alignment=TA_CENTER)))
        story.append(Paragraph(f"Especialidad: {r[12]}", ParagraphStyle('Center', parent=styles['Normal'], alignment=TA_CENTER, fontSize=9)))
        story.append(Paragraph(f"Cédula: {r[14]}", ParagraphStyle('Center', parent=styles['Normal'], alignment=TA_CENTER, fontSize=9)))
        
        story.append(Spacer(1, 0.2*inch))
        story.append(Paragraph(
            "Este documento es confidencial y está protegido por las leyes de privacidad médica.<br/>"
            "Clínica Vital © 2025 - Todos los derechos reservados<br/>"
            f"Generado: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}",
            ParagraphStyle('Footer', parent=styles['Normal'], fontSize=8, textColor=colors.grey, alignment=TA_CENTER)
        ))
        
        doc.build(story)
        pdf_buffer.seek(0)
        
        response = make_response(pdf_buffer.getvalue())
        response.headers['Content-Type'] = 'application/pdf'
        response.headers['Content-Disposition'] = f'attachment; filename=Receta_{r[14]}_{receta_id}.pdf'
        response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
        
        return response
        
    except Exception as e:
        flash(f'Error al generar PDF: {str(e)}', 'danger')
        return redirect(url_for('paciente.mis_recetas'))
    finally:
        cursor.close()


# =====================================
# CITAS
# =====================================
@paciente_bp.route('/mis-citas')
@login_required
@role_required('paciente')
def mis_citas():
    cursor = g.mysql.connection.cursor()

    try:
        cursor.execute("SELECT id FROM pacientes WHERE usuario_id = %s", (session['usuario_id'],))
        paciente = cursor.fetchone()
        
        if not paciente:
            flash('No se encontró información del paciente', 'danger')
            return redirect(url_for('paciente.dashboard'))
        
        paciente_id = paciente[0]

        query = """
            SELECT c.*, u.nombre_completo as doctor_nombre, e.nombre as especialidad
            FROM citas c
            JOIN doctores d ON c.doctor_id = d.id
            JOIN usuarios u ON d.usuario_id = u.id
            JOIN especialidades e ON d.especialidad_id = e.id
            WHERE c.paciente_id = %s
            ORDER BY c.fecha_hora DESC
        """
        cursor.execute(query, (paciente_id,))
        citas = cursor.fetchall()
        
        return render_template('paciente/mis_citas.html', citas=citas)
        
    except Exception as e:
        flash(f'Error al cargar las citas: {str(e)}', 'danger')
        return redirect(url_for('paciente.dashboard'))
    finally:
        cursor.close()


@paciente_bp.route('/agendar-cita', methods=['GET', 'POST'])
@login_required
@role_required('paciente')
def agendar_cita():
    cursor = g.mysql.connection.cursor()
    
    try:
        paciente = None
        cursor.execute("SELECT id FROM pacientes WHERE usuario_id = %s", (session['usuario_id'],))
        resultado = cursor.fetchone()
        if resultado:
            paciente = resultado[0]
        
        if request.method == 'POST':
            if not paciente:
                flash('No se encontró información del paciente', 'danger')
                return redirect(url_for('paciente.agendar_cita'))
            
            doctor_id = request.form.get('doctor_id')
            fecha = request.form.get('fecha')
            hora = request.form.get('hora')
            motivo = request.form.get('motivo')
            
            fecha_hora = f"{fecha} {hora}"
            
            cursor.execute("""
                INSERT INTO citas (paciente_id, doctor_id, fecha_hora, motivo, estado, creada_por)
                VALUES (%s, %s, %s, %s, 'programada', %s)
            """, (paciente, doctor_id, fecha_hora, motivo, session['usuario_id']))
            
            g.mysql.connection.commit()
            
            flash('Cita agendada exitosamente', 'success')
            return redirect(url_for('paciente.mis_citas'))
        
        cursor.execute("""
            SELECT d.id, u.nombre_completo, e.nombre as especialidad
            FROM doctores d
            JOIN usuarios u ON d.usuario_id = u.id
            JOIN especialidades e ON d.especialidad_id = e.id
            WHERE u.activo = TRUE
            ORDER BY e.nombre, u.nombre_completo
        """)
        doctores = cursor.fetchall()
        
        return render_template('paciente/agendar_cita.html', doctores=doctores)
        
    except Exception as e:
        g.mysql.connection.rollback()
        flash(f'Error al agendar cita: {str(e)}', 'danger')
        return redirect(url_for('paciente.dashboard'))
    finally:
        cursor.close()


@paciente_bp.route('/elegir-doctor')
@login_required
@role_required('paciente')
def elegir_doctor():
    cursor = g.mysql.connection.cursor()
    
    try:
        query = """
            SELECT d.id, u.nombre_completo, e.nombre as especialidad, 
                   u.email, u.telefono, COUNT(c.id) as total_citas
            FROM doctores d
            JOIN usuarios u ON d.usuario_id = u.id
            JOIN especialidades e ON d.especialidad_id = e.id
            LEFT JOIN citas c ON d.id = c.doctor_id
            WHERE u.activo = TRUE
            GROUP BY d.id, u.nombre_completo, e.nombre, u.email, u.telefono
            ORDER BY e.nombre, u.nombre_completo
        """
        cursor.execute(query)
        doctores = cursor.fetchall()
        
        return render_template('paciente/elegir_doctor.html', doctores=doctores)
        
    except Exception as e:
        flash(f'Error al cargar doctores: {str(e)}', 'danger')
        return redirect(url_for('paciente.dashboard'))
    finally:
        cursor.close()


# =====================================
# MENSAJES
# =====================================
@paciente_bp.route('/mensajes')
@login_required
@role_required('paciente')
def mensajes():
    cursor = g.mysql.connection.cursor()
    
    try:
        cursor.execute("SELECT id FROM pacientes WHERE usuario_id = %s", (session['usuario_id'],))
        paciente = cursor.fetchone()
        
        if not paciente:
            flash('No se encontró información del paciente', 'danger')
            return redirect(url_for('paciente.dashboard'))
        
        paciente_id = paciente[0]
        
        query = """
            SELECT DISTINCT d.id, u.nombre_completo as doctor_nombre, 
                   e.nombre as especialidad, COUNT(m.id) as sin_leer
            FROM doctores d
            JOIN usuarios u ON d.usuario_id = u.id
            JOIN especialidades e ON d.especialidad_id = e.id
            LEFT JOIN mensajes m ON (m.doctor_id = d.id AND m.paciente_id = %s AND m.leido = FALSE)
            WHERE u.activo = TRUE
            GROUP BY d.id, u.nombre_completo, e.nombre
            ORDER BY sin_leer DESC, u.nombre_completo
        """
        cursor.execute(query, (paciente_id,))
        conversaciones = cursor.fetchall()
        
        return render_template('paciente/mensajes.html', conversaciones=conversaciones)
        
    except Exception as e:
        flash(f'Error al cargar mensajes: {str(e)}', 'danger')
        return redirect(url_for('paciente.dashboard'))
    finally:
        cursor.close()


@paciente_bp.route('/mensajes/<int:doctor_id>')
@login_required
@role_required('paciente')
def ver_conversacion(doctor_id):
    cursor = g.mysql.connection.cursor()
    
    try:
        cursor.execute("SELECT id FROM pacientes WHERE usuario_id = %s", (session['usuario_id'],))
        paciente = cursor.fetchone()
        
        if not paciente:
            flash('No se encontró información del paciente', 'danger')
            return redirect(url_for('paciente.dashboard'))
        
        paciente_id = paciente[0]
        
        query_doctor = """
            SELECT d.id, u.nombre_completo, e.nombre as especialidad, u.email, u.telefono
            FROM doctores d
            JOIN usuarios u ON d.usuario_id = u.id
            JOIN especialidades e ON d.especialidad_id = e.id
            WHERE d.id = %s AND u.activo = TRUE
        """
        cursor.execute(query_doctor, (doctor_id,))
        doctor = cursor.fetchone()
        
        if not doctor:
            flash('Doctor no encontrado', 'danger')
            return redirect(url_for('paciente.mensajes'))
        
        cursor.execute("""
            UPDATE mensajes 
            SET leido = TRUE 
            WHERE paciente_id = %s AND doctor_id = %s AND remitente = 'doctor'
        """, (paciente_id, doctor_id))
        g.mysql.connection.commit()
        
        query_mensajes = """
            SELECT id, remitente, contenido, fecha_hora
            FROM mensajes
            WHERE (paciente_id = %s AND doctor_id = %s)
            ORDER BY fecha_hora ASC
        """
        cursor.execute(query_mensajes, (paciente_id, doctor_id))
        mensajes = cursor.fetchall()
        
        registrar_auditoria(
            usuario_id=session['usuario_id'],
            accion='ver_conversacion',
            modulo='mensajes',
            registro_id=doctor_id,
            detalles=f'Paciente consultó conversación con doctor ID {doctor_id}'
        )
        
        return render_template('paciente/ver_conversacion.html', doctor=doctor, mensajes=mensajes, paciente_id=paciente_id)
        
    except Exception as e:
        flash(f'Error al cargar conversación: {str(e)}', 'danger')
        return redirect(url_for('paciente.mensajes'))
    finally:
        cursor.close()


@paciente_bp.route('/mensajes/<int:doctor_id>/enviar', methods=['POST'])
@login_required
@role_required('paciente')
def enviar_mensaje(doctor_id):
    cursor = g.mysql.connection.cursor()
    
    try:
        cursor.execute("SELECT id FROM pacientes WHERE usuario_id = %s", (session['usuario_id'],))
        paciente = cursor.fetchone()
        
        if not paciente:
            flash('No se encontró información del paciente', 'danger')
            return redirect(url_for('paciente.dashboard'))
        
        paciente_id = paciente[0]
        contenido = request.form.get('contenido', '').strip()
        
        if not contenido:
            flash('El mensaje no puede estar vacío', 'warning')
            return redirect(url_for('paciente.ver_conversacion', doctor_id=doctor_id))
        
        cursor.execute("""
            INSERT INTO mensajes (paciente_id, doctor_id, remitente, contenido)
            VALUES (%s, %s, 'paciente', %s)
        """, (paciente_id, doctor_id, contenido))
        
        g.mysql.connection.commit()
        
        registrar_auditoria(
            usuario_id=session['usuario_id'],
            accion='enviar_mensaje',
            modulo='mensajes',
            registro_id=doctor_id,
            detalles=f'Paciente envió mensaje a doctor ID {doctor_id}'
        )
        
        flash('Mensaje enviado exitosamente', 'success')
        return redirect(url_for('paciente.ver_conversacion', doctor_id=doctor_id))
        
    except Exception as e:
        g.mysql.connection.rollback()
        flash(f'Error al enviar mensaje: {str(e)}', 'danger')
        return redirect(url_for('paciente.ver_conversacion', doctor_id=doctor_id))
    finally:
        cursor.close()


#=====================================
# CAMBIAR CONTRASEÑA
#=====================================
@paciente_bp.route('/cambiar-contrasena', methods=['GET', 'POST'])
@login_required
@role_required('paciente')
def cambiar_contrasena():
    """Cambiar contraseña del paciente"""
    if request.method == 'POST':
        contrasena_actual = request.form.get('contrasena_actual')
        contrasena_nueva = request.form.get('contrasena_nueva')
        contrasena_confirmar = request.form.get('contrasena_confirmar')
        
        cursor = g.mysql.connection.cursor()
        
        try:
            # Obtener usuario actual
            cursor.execute("SELECT password FROM usuarios WHERE id = %s", (session['usuario_id'],))
            usuario = cursor.fetchone()
            
            if not usuario:
                flash('❌ Usuario no encontrado', 'danger')
                return redirect(url_for('paciente.dashboard'))
            
            # Verificar contraseña actual
            if not check_password_hash(usuario[0], contrasena_actual):
                flash('❌ Contraseña actual incorrecta', 'danger')
                return redirect(url_for('paciente.cambiar_contrasena'))
            
            # Validar que las contraseñas nuevas coincidan
            if contrasena_nueva != contrasena_confirmar:
                flash('❌ Las contraseñas nuevas no coinciden', 'danger')
                return redirect(url_for('paciente.cambiar_contrasena'))
            
            # Validar que la contraseña tenga mínimo 6 caracteres
            if len(contrasena_nueva) < 6:
                flash('❌ La contraseña debe tener mínimo 6 caracteres', 'warning')
                return redirect(url_for('paciente.cambiar_contrasena'))
            
            # Generar hash de nueva contraseña
            nueva_hash = generate_password_hash(contrasena_nueva)
            
            # Actualizar contraseña
            cursor.execute("UPDATE usuarios SET password = %s WHERE id = %s", 
                         (nueva_hash, session['usuario_id']))
            g.mysql.connection.commit()
            
            flash('✅ Contraseña actualizada exitosamente', 'success')
            return redirect(url_for('paciente.dashboard'))
            
        except Exception as e:
            g.mysql.connection.rollback()
            flash(f'❌ Error al cambiar contraseña: {str(e)}', 'danger')
            return redirect(url_for('paciente.cambiar_contrasena'))
        finally:
            cursor.close()
    
    return render_template('paciente/cambiar_contrasena.html')