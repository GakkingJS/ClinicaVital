-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: clinica_vital
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auditoria`
--

DROP TABLE IF EXISTS `auditoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auditoria` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `accion` varchar(100) NOT NULL,
  `modulo` varchar(50) NOT NULL,
  `registro_id` int(11) DEFAULT NULL,
  `detalles` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `fecha_accion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_auditoria_usuario` (`usuario_id`),
  KEY `idx_auditoria_fecha` (`fecha_accion`),
  CONSTRAINT `auditoria_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=134 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditoria`
--

LOCK TABLES `auditoria` WRITE;
/*!40000 ALTER TABLE `auditoria` DISABLE KEYS */;
INSERT INTO `auditoria` VALUES (1,5,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-23 22:21:02'),(2,5,'logout','sistema',NULL,NULL,'127.0.0.1','2025-10-23 22:21:15'),(3,3,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-24 22:53:39'),(4,5,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-24 22:54:19'),(5,5,'logout','sistema',NULL,NULL,'127.0.0.1','2025-10-24 22:54:49'),(6,4,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-24 22:55:03'),(7,4,'logout','sistema',NULL,NULL,'127.0.0.1','2025-10-24 22:55:43'),(8,6,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-24 22:56:08'),(9,6,'logout','sistema',NULL,NULL,'127.0.0.1','2025-10-24 22:59:46'),(10,3,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-24 22:59:58'),(11,3,'logout','sistema',NULL,NULL,'127.0.0.1','2025-10-24 23:01:04'),(12,3,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-25 00:11:14'),(13,3,'logout','sistema',NULL,NULL,'127.0.0.1','2025-10-25 00:12:14'),(14,4,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-25 00:12:34'),(15,4,'logout','sistema',NULL,NULL,'127.0.0.1','2025-10-25 00:13:16'),(16,6,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-25 00:13:48'),(17,6,'logout','sistema',NULL,NULL,'127.0.0.1','2025-10-25 00:14:30'),(18,5,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-25 00:14:40'),(19,5,'logout','sistema',NULL,NULL,'127.0.0.1','2025-10-25 00:16:02'),(20,3,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-29 22:04:07'),(21,3,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-29 22:07:44'),(22,3,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-29 22:08:39'),(23,3,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 03:39:49'),(24,5,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 03:40:19'),(25,4,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 03:40:46'),(26,6,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 03:41:36'),(27,3,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 03:42:06'),(28,3,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 04:16:12'),(29,3,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 04:16:21'),(30,3,'logout','sistema',NULL,NULL,'127.0.0.1','2025-10-30 05:26:49'),(31,5,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 05:26:57'),(32,4,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 05:36:10'),(33,4,'logout','sistema',NULL,NULL,'127.0.0.1','2025-10-30 05:43:24'),(34,5,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 05:43:34'),(35,6,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 05:44:26'),(36,6,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 12:58:28'),(37,4,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 13:00:01'),(38,3,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 13:00:13'),(39,3,'logout','sistema',NULL,NULL,'127.0.0.1','2025-10-30 13:00:34'),(40,5,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 13:00:42'),(41,4,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 15:55:58'),(42,4,'logout','sistema',NULL,NULL,'127.0.0.1','2025-10-30 16:01:50'),(43,6,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 16:02:10'),(44,6,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 16:32:20'),(45,6,'logout','sistema',NULL,NULL,'127.0.0.1','2025-10-30 16:59:13'),(46,4,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 16:59:27'),(47,4,'crear_historia_clinica','historias_clinicas',NULL,'Historia clínica creada para paciente ID: 1','127.0.0.1','2025-10-30 19:41:31'),(48,4,'crear_receta','recetas',NULL,'Receta creada para paciente ID: 1','127.0.0.1','2025-10-30 20:26:04'),(49,4,'logout','sistema',NULL,NULL,'127.0.0.1','2025-10-30 20:26:28'),(50,6,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 20:26:35'),(51,6,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 20:27:37'),(52,6,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 20:58:56'),(53,6,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 20:59:05'),(54,6,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 20:59:13'),(55,6,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 20:59:34'),(56,4,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 21:01:03'),(57,4,'crear_historia_clinica','historias_clinicas',NULL,'Historia clínica creada para paciente ID: 1','127.0.0.1','2025-10-30 21:05:42'),(58,4,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 21:06:08'),(59,4,'logout','sistema',NULL,NULL,'127.0.0.1','2025-10-30 21:07:39'),(60,6,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 21:07:47'),(61,6,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 21:07:58'),(62,3,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 21:08:03'),(63,3,'logout','sistema',NULL,NULL,'127.0.0.1','2025-10-30 21:09:34'),(64,6,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 21:13:56'),(65,6,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 21:15:08'),(66,6,'logout','sistema',NULL,NULL,'127.0.0.1','2025-10-30 21:16:20'),(67,6,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 21:16:29'),(68,6,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 21:24:06'),(69,6,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 21:25:03'),(70,6,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 21:33:53'),(71,6,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 21:36:19'),(72,6,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 21:38:56'),(73,6,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 21:41:57'),(74,6,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 21:45:53'),(75,6,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 21:49:52'),(76,6,'ver_historia_clinica','historias_clinicas',NULL,'Paciente consultó sus historias clínicas','127.0.0.1','2025-10-30 22:31:16'),(77,6,'ver_historia_clinica','historias_clinicas',NULL,'Paciente consultó sus historias clínicas','127.0.0.1','2025-10-30 22:46:37'),(78,6,'ver_historia_clinica','historias_clinicas',NULL,'Paciente consultó sus historias clínicas','127.0.0.1','2025-10-30 22:50:21'),(79,6,'ver_historia_clinica','historias_clinicas',NULL,'Paciente consultó sus historias clínicas','127.0.0.1','2025-10-30 22:53:51'),(80,6,'ver_historia_clinica','historias_clinicas',NULL,'Paciente consultó sus historias clínicas','127.0.0.1','2025-10-30 22:56:05'),(81,6,'ver_historia_clinica','historias_clinicas',NULL,'Paciente consultó sus historias clínicas','127.0.0.1','2025-10-30 22:57:48'),(82,6,'ver_historia_clinica','historias_clinicas',NULL,'Paciente consultó sus historias clínicas','127.0.0.1','2025-10-30 23:00:23'),(83,6,'ver_detalle_historia','historias_clinicas',4,'Paciente consultó detalles de historia clínica ID 4','127.0.0.1','2025-10-30 23:00:24'),(84,6,'ver_historia_clinica','historias_clinicas',NULL,'Paciente consultó sus historias clínicas','127.0.0.1','2025-10-30 23:00:31'),(85,6,'ver_historia_clinica','historias_clinicas',NULL,'Paciente consultó sus historias clínicas','127.0.0.1','2025-10-30 23:11:18'),(86,6,'ver_detalle_historia','historias_clinicas',4,'Paciente consultó detalles de historia clínica ID 4','127.0.0.1','2025-10-30 23:11:20'),(87,6,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 23:23:24'),(88,6,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 23:23:45'),(89,6,'ver_conversacion','mensajes',1,'Paciente consultó conversación con doctor ID 1','127.0.0.1','2025-10-30 23:36:05'),(90,6,'enviar_mensaje','mensajes',1,'Paciente envió mensaje a doctor ID 1','127.0.0.1','2025-10-30 23:36:09'),(91,6,'ver_conversacion','mensajes',1,'Paciente consultó conversación con doctor ID 1','127.0.0.1','2025-10-30 23:36:09'),(92,6,'logout','sistema',NULL,NULL,'127.0.0.1','2025-10-30 23:36:15'),(93,4,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 23:36:27'),(94,4,'logout','sistema',NULL,NULL,'127.0.0.1','2025-10-30 23:40:59'),(95,5,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 23:41:08'),(96,4,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 23:44:14'),(97,4,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 23:49:13'),(98,4,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 23:49:31'),(99,4,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 23:53:27'),(100,4,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-30 23:53:55'),(101,4,'enviar_mensaje','mensajes',1,'Doctor envió mensaje a paciente ID 1','127.0.0.1','2025-10-31 00:11:11'),(102,4,'logout','sistema',NULL,NULL,'127.0.0.1','2025-10-31 00:11:13'),(103,6,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-31 00:11:19'),(104,6,'ver_historia_clinica','historias_clinicas',NULL,'Paciente consultó sus historias clínicas','127.0.0.1','2025-10-31 00:11:28'),(105,6,'ver_conversacion','mensajes',1,'Paciente consultó conversación con doctor ID 1','127.0.0.1','2025-10-31 00:11:38'),(106,6,'logout','sistema',NULL,NULL,'127.0.0.1','2025-10-31 00:21:01'),(107,3,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-31 00:21:08'),(108,3,'logout','sistema',NULL,NULL,'127.0.0.1','2025-10-31 01:41:24'),(109,4,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-31 01:42:07'),(110,4,'enviar_mensaje','mensajes',1,'Doctor envió mensaje a paciente ID 1','127.0.0.1','2025-10-31 01:42:53'),(111,4,'logout','sistema',NULL,NULL,'127.0.0.1','2025-10-31 01:43:58'),(112,3,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-31 01:44:09'),(113,3,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-31 20:13:17'),(114,3,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-31 20:14:07'),(115,3,'logout','sistema',NULL,NULL,'127.0.0.1','2025-10-31 21:57:20'),(116,4,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-31 21:57:34'),(117,4,'logout','sistema',NULL,NULL,'127.0.0.1','2025-10-31 22:14:59'),(118,6,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-31 22:15:06'),(119,6,'ver_historia_clinica','historias_clinicas',NULL,'Paciente consultó sus historias clínicas','127.0.0.1','2025-10-31 22:15:08'),(120,5,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-31 22:24:26'),(121,5,'logout','sistema',NULL,NULL,'127.0.0.1','2025-10-31 22:36:54'),(122,5,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-31 22:37:05'),(123,5,'crear','pacientes',11,NULL,'127.0.0.1','2025-10-31 22:38:22'),(124,5,'logout','sistema',NULL,NULL,'127.0.0.1','2025-10-31 22:40:19'),(125,3,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-31 22:40:25'),(126,3,'logout','sistema',NULL,NULL,'127.0.0.1','2025-10-31 22:45:12'),(127,4,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-31 22:45:21'),(128,4,'logout','sistema',NULL,NULL,'127.0.0.1','2025-10-31 22:45:36'),(129,6,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-31 22:45:44'),(130,6,'logout','sistema',NULL,NULL,'127.0.0.1','2025-10-31 22:46:03'),(131,5,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-31 22:46:21'),(132,5,'logout','sistema',NULL,NULL,'127.0.0.1','2025-10-31 22:57:46'),(133,3,'login','sistema',NULL,NULL,'127.0.0.1','2025-10-31 22:57:54');
/*!40000 ALTER TABLE `auditoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auditoria_historias`
--

DROP TABLE IF EXISTS `auditoria_historias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auditoria_historias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `historia_id` int(11) NOT NULL,
  `paciente_id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `accion` varchar(20) NOT NULL,
  `tabla` varchar(50) NOT NULL,
  `campo_modificado` varchar(100) DEFAULT NULL,
  `valor_anterior` text DEFAULT NULL,
  `valor_nuevo` text DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `fecha_hora` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `historia_id` (`historia_id`),
  KEY `paciente_id` (`paciente_id`),
  KEY `doctor_id` (`doctor_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `auditoria_historias_ibfk_1` FOREIGN KEY (`historia_id`) REFERENCES `historias_clinicas` (`id`),
  CONSTRAINT `auditoria_historias_ibfk_2` FOREIGN KEY (`paciente_id`) REFERENCES `pacientes` (`id`),
  CONSTRAINT `auditoria_historias_ibfk_3` FOREIGN KEY (`doctor_id`) REFERENCES `doctores` (`id`),
  CONSTRAINT `auditoria_historias_ibfk_4` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditoria_historias`
--

LOCK TABLES `auditoria_historias` WRITE;
/*!40000 ALTER TABLE `auditoria_historias` DISABLE KEYS */;
/*!40000 ALTER TABLE `auditoria_historias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `citas`
--

DROP TABLE IF EXISTS `citas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `citas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paciente_id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `fecha_hora` datetime NOT NULL,
  `duracion_minutos` int(11) DEFAULT 30,
  `motivo` varchar(255) DEFAULT NULL,
  `estado` enum('programada','confirmada','completada','cancelada') DEFAULT 'programada',
  `observaciones` text DEFAULT NULL,
  `creada_por` int(11) NOT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `creada_por` (`creada_por`),
  KEY `idx_citas_fecha` (`fecha_hora`),
  KEY `idx_citas_doctor` (`doctor_id`),
  KEY `idx_citas_paciente` (`paciente_id`),
  CONSTRAINT `citas_ibfk_1` FOREIGN KEY (`paciente_id`) REFERENCES `pacientes` (`id`),
  CONSTRAINT `citas_ibfk_2` FOREIGN KEY (`doctor_id`) REFERENCES `doctores` (`id`),
  CONSTRAINT `citas_ibfk_3` FOREIGN KEY (`creada_por`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `citas`
--

LOCK TABLES `citas` WRITE;
/*!40000 ALTER TABLE `citas` DISABLE KEYS */;
INSERT INTO `citas` VALUES (1,1,1,'2025-10-23 19:19:20',30,'Consulta general','programada',NULL,3,'2025-10-23 22:19:20'),(3,1,1,'2026-01-12 14:40:00',30,'gripe','programada',NULL,6,'2025-10-30 21:54:16'),(4,1,1,'2026-01-12 14:40:00',30,'gripe','programada',NULL,6,'2025-10-30 21:55:27');
/*!40000 ALTER TABLE `citas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuracion`
--

DROP TABLE IF EXISTS `configuracion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuracion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clave` varchar(100) NOT NULL,
  `valor` text DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `clave` (`clave`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuracion`
--

LOCK TABLES `configuracion` WRITE;
/*!40000 ALTER TABLE `configuracion` DISABLE KEYS */;
INSERT INTO `configuracion` VALUES (1,'nombre_clinica','Clínica Vital','Nombre de la clínica','2025-10-31 21:33:08'),(2,'email_clinica','contacto@clinicavital.com','Email de contacto','2025-10-31 21:33:08'),(3,'telefono_clinica','+57 300 123 4567','Teléfono principal','2025-10-31 21:33:08'),(4,'direccion_clinica','Calle 5#45-67, Ibagué, Colombia','Dirección física','2025-10-31 21:38:24'),(5,'horario_atencion','Lunes a Viernes: 8:00 AM - 6:00 PM','Horario de atención','2025-10-31 21:33:08'),(6,'logo_url','/static/img/logo.png','URL del logo','2025-10-31 21:33:08');
/*!40000 ALTER TABLE `configuracion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doctores`
--

DROP TABLE IF EXISTS `doctores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doctores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `especialidad_id` int(11) NOT NULL,
  `numero_licencia` varchar(50) NOT NULL,
  `anos_experiencia` int(11) DEFAULT NULL,
  `horario_atencion` text DEFAULT NULL,
  `licencia_medica` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuario_id` (`usuario_id`),
  UNIQUE KEY `numero_licencia` (`numero_licencia`),
  KEY `especialidad_id` (`especialidad_id`),
  CONSTRAINT `doctores_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `doctores_ibfk_2` FOREIGN KEY (`especialidad_id`) REFERENCES `especialidades` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctores`
--

LOCK TABLES `doctores` WRITE;
/*!40000 ALTER TABLE `doctores` DISABLE KEYS */;
INSERT INTO `doctores` VALUES (1,4,1,'LIC-12345',10,NULL,NULL),(2,8,193,'',12,NULL,'LIC-1234');
/*!40000 ALTER TABLE `doctores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `especialidades`
--

DROP TABLE IF EXISTS `especialidades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `especialidades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `activo` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=211 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `especialidades`
--

LOCK TABLES `especialidades` WRITE;
/*!40000 ALTER TABLE `especialidades` DISABLE KEYS */;
INSERT INTO `especialidades` VALUES (1,'Medicina General','Atención médica general',1),(2,'Cardiología','Especialista en corazón y sistema cardiovascular',1),(3,'Pediatría','Especialista en niños y adolescentes',1),(4,'Ginecología','Especialista en salud femenina',1),(5,'Dermatología','Especialista en piel',1),(6,'Odontología','Especialista en salud dental',1),(188,'Oftalmología','Especialista en enfermedades de los ojos',1),(189,'Otorrinolaringología','Especialista en oído, nariz y garganta',1),(190,'Neurocirugía','Especialista en cirugía del sistema nervioso',1),(191,'Neurología','Especialista en enfermedades del sistema nervioso',1),(192,'Psiquiatría','Especialista en salud mental',1),(193,'Urología','Especialista en enfermedades urinarias',1),(194,'Neumología','Especialista en enfermedades pulmonares',1),(195,'Gastroenterología','Especialista en enfermedades digestivas',1),(196,'Oncología','Especialista en cáncer',1),(197,'Hematología','Especialista en enfermedades de la sangre',1),(198,'Endocrinología','Especialista en enfermedades hormonales',1),(199,'Traumatología','Especialista en lesiones óseas y articulares',1),(200,'Cirugía General','Cirujano general',1),(201,'Anestesiología','Especialista en anestesia',1),(202,'Radiología','Especialista en diagnóstico por imagen',1),(203,'Patología','Especialista en análisis de tejidos',1),(204,'Medicina Intensiva','Especialista en cuidados intensivos',1),(205,'Infectología','Especialista en enfermedades infecciosas',1),(206,'Reumatología','Especialista en enfermedades articulares',1),(207,'Alergología','Especialista en alergias',1),(208,'Medicina del Deporte','Especialista en medicina deportiva',1),(209,'Estética','Especialista en medicina estética',1);
/*!40000 ALTER TABLE `especialidades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `historias_clinicas`
--

DROP TABLE IF EXISTS `historias_clinicas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `historias_clinicas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paciente_id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `fecha_consulta` timestamp NOT NULL DEFAULT current_timestamp(),
  `motivo_consulta` text NOT NULL,
  `sintomas` text DEFAULT NULL,
  `diagnostico` text DEFAULT NULL,
  `observaciones` text DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `presion_arterial` varchar(20) DEFAULT NULL,
  `temperatura` decimal(4,2) DEFAULT NULL,
  `peso` decimal(5,2) DEFAULT NULL,
  `altura` decimal(5,2) DEFAULT NULL,
  `tratamiento` text DEFAULT NULL,
  `usuario_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_historias_paciente` (`paciente_id`),
  KEY `idx_paciente` (`paciente_id`),
  KEY `idx_doctor` (`doctor_id`),
  KEY `idx_fecha` (`fecha_consulta`),
  CONSTRAINT `fk_doctor` FOREIGN KEY (`doctor_id`) REFERENCES `doctores` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_paciente` FOREIGN KEY (`paciente_id`) REFERENCES `pacientes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `historias_clinicas_ibfk_1` FOREIGN KEY (`paciente_id`) REFERENCES `pacientes` (`id`),
  CONSTRAINT `historias_clinicas_ibfk_2` FOREIGN KEY (`doctor_id`) REFERENCES `doctores` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `historias_clinicas`
--

LOCK TABLES `historias_clinicas` WRITE;
/*!40000 ALTER TABLE `historias_clinicas` DISABLE KEYS */;
INSERT INTO `historias_clinicas` VALUES (1,1,1,'2025-10-30 19:33:54','gripe','Debilidad','gripe','','2025-10-30 22:10:09','80',37.00,71.00,173.00,'acetaminofen cada 8 horas',0),(2,1,1,'2025-10-30 19:41:31','gripe','Debilidad','gripe','','2025-10-30 22:10:09','80',37.00,71.00,173.00,'acetaminofen cada 8 horas',0),(3,1,1,'2025-10-30 21:05:42','gripe','dolor de cabeza','gripe','','2025-10-30 22:10:09','80',38.00,80.00,176.00,'acetaminofen',0),(4,1,1,'2025-10-30 22:49:50','Consulta de rutina','Dolor de cabeza leve','Migraña tensional','Paciente presenta síntomas de migraña','2025-10-30 22:49:50','120/80',37.20,70.50,175.00,'Reposo y analgésicos si es necesario',1);
/*!40000 ALTER TABLE `historias_clinicas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicamentos_receta`
--

DROP TABLE IF EXISTS `medicamentos_receta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medicamentos_receta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receta_id` int(11) NOT NULL,
  `nombre_medicamento` varchar(200) NOT NULL,
  `dosis` varchar(100) NOT NULL,
  `frecuencia` varchar(100) NOT NULL,
  `duracion` varchar(100) NOT NULL,
  `instrucciones_especiales` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `receta_id` (`receta_id`),
  CONSTRAINT `medicamentos_receta_ibfk_1` FOREIGN KEY (`receta_id`) REFERENCES `recetas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicamentos_receta`
--

LOCK TABLES `medicamentos_receta` WRITE;
/*!40000 ALTER TABLE `medicamentos_receta` DISABLE KEYS */;
/*!40000 ALTER TABLE `medicamentos_receta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mensajes`
--

DROP TABLE IF EXISTS `mensajes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mensajes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paciente_id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `remitente` varchar(20) NOT NULL,
  `contenido` text NOT NULL,
  `leido` tinyint(1) DEFAULT 0,
  `fecha_hora` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_paciente` (`paciente_id`),
  KEY `idx_doctor` (`doctor_id`),
  KEY `idx_fecha` (`fecha_hora`),
  CONSTRAINT `mensajes_ibfk_1` FOREIGN KEY (`paciente_id`) REFERENCES `pacientes` (`id`),
  CONSTRAINT `mensajes_ibfk_2` FOREIGN KEY (`doctor_id`) REFERENCES `doctores` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mensajes`
--

LOCK TABLES `mensajes` WRITE;
/*!40000 ALTER TABLE `mensajes` DISABLE KEYS */;
INSERT INTO `mensajes` VALUES (1,1,1,'paciente','hola',1,'2025-10-30 23:36:09'),(2,1,1,'doctor','hola',1,'2025-10-31 00:11:11'),(3,1,1,'doctor','comoe stas?',0,'2025-10-31 01:42:53');
/*!40000 ALTER TABLE `mensajes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pacientes`
--

DROP TABLE IF EXISTS `pacientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pacientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `cedula` varchar(20) DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `genero` enum('Masculino','Femenino','Otro') DEFAULT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `ciudad` varchar(100) DEFAULT 'Ibagué',
  `telefono` varchar(20) DEFAULT NULL,
  `tipo_sangre` varchar(5) DEFAULT NULL,
  `alergias` text DEFAULT NULL,
  `enfermedades_cronicas` text DEFAULT NULL,
  `medicamentos_actuales` text DEFAULT NULL,
  `contacto_emergencia` varchar(150) DEFAULT NULL,
  `telefono_emergencia` varchar(20) DEFAULT NULL,
  `parentesco_emergencia` varchar(50) DEFAULT NULL,
  `eps` varchar(100) DEFAULT NULL,
  `numero_afiliacion` varchar(50) DEFAULT NULL,
  `estado_civil` enum('Soltero','Casado','Divorciado','Viudo','Union Libre') DEFAULT NULL,
  `ocupacion` varchar(100) DEFAULT NULL,
  `nivel_educativo` varchar(50) DEFAULT NULL,
  `peso_kg` decimal(5,2) DEFAULT NULL,
  `altura_cm` decimal(5,2) DEFAULT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  `ultima_actualizacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuario_id` (`usuario_id`),
  UNIQUE KEY `idx_cedula_unique` (`cedula`),
  KEY `idx_usuario_id` (`usuario_id`),
  CONSTRAINT `pacientes_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pacientes`
--

LOCK TABLES `pacientes` WRITE;
/*!40000 ALTER TABLE `pacientes` DISABLE KEYS */;
INSERT INTO `pacientes` VALUES (1,6,NULL,NULL,NULL,NULL,'Ibagué',NULL,'O+','','',NULL,'Ana Rodríguez','3125555555',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-30 16:44:31','2025-10-30 16:58:56'),(2,11,NULL,NULL,NULL,NULL,'Ibagué',NULL,'B+',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-31 22:38:22','2025-10-31 22:38:22');
/*!40000 ALTER TABLE `pacientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permisos`
--

DROP TABLE IF EXISTS `permisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permisos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `modulo` varchar(50) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permisos`
--

LOCK TABLES `permisos` WRITE;
/*!40000 ALTER TABLE `permisos` DISABLE KEYS */;
INSERT INTO `permisos` VALUES (1,'ver_perfil','Ver información de perfil','general','2025-10-31 21:12:21'),(2,'editar_perfil','Editar información de perfil','general','2025-10-31 21:12:21'),(3,'ver_citas','Ver listado de citas','citas','2025-10-31 21:12:21'),(4,'crear_cita','Crear nueva cita','citas','2025-10-31 21:12:21'),(5,'editar_cita','Editar cita existente','citas','2025-10-31 21:12:21'),(6,'cancelar_cita','Cancelar cita','citas','2025-10-31 21:12:21'),(7,'gestionar_todas_citas','Gestionar citas de todos los usuarios','citas','2025-10-31 21:12:21'),(8,'ver_historia_propia','Ver su propia historia clínica','historias','2025-10-31 21:12:21'),(9,'ver_todas_historias','Ver historias clínicas de pacientes','historias','2025-10-31 21:12:21'),(10,'crear_historia','Crear historia clínica','historias','2025-10-31 21:12:21'),(11,'editar_historia','Editar historia clínica','historias','2025-10-31 21:12:21'),(12,'ver_recetas_propias','Ver sus propias recetas','recetas','2025-10-31 21:12:21'),(13,'crear_receta','Prescribir recetas médicas','recetas','2025-10-31 21:12:21'),(14,'ver_todas_recetas','Ver todas las recetas','recetas','2025-10-31 21:12:21'),(15,'ver_usuarios','Ver listado de usuarios','usuarios','2025-10-31 21:12:21'),(16,'crear_usuario','Crear nuevo usuario','usuarios','2025-10-31 21:12:21'),(17,'editar_usuario','Editar información de usuario','usuarios','2025-10-31 21:12:21'),(18,'desactivar_usuario','Desactivar/activar usuario','usuarios','2025-10-31 21:12:21'),(19,'gestionar_roles','Gestionar roles y permisos','admin','2025-10-31 21:12:21'),(20,'ver_reportes','Ver reportes del sistema','admin','2025-10-31 21:12:21'),(21,'ver_auditoria','Ver registro de auditoría','admin','2025-10-31 21:12:21'),(22,'configurar_sistema','Modificar configuración del sistema','admin','2025-10-31 21:12:21'),(23,'gestionar_especialidades','Gestionar especialidades médicas','admin','2025-10-31 21:12:21'),(24,'crear_doctor','Crear nuevo doctor','personal','2025-10-31 21:12:21'),(25,'crear_secretaria','Crear nueva secretaria','personal','2025-10-31 21:12:21'),(26,'crear_admin','Crear nuevo administrador','personal','2025-10-31 21:12:21');
/*!40000 ALTER TABLE `permisos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recetas`
--

DROP TABLE IF EXISTS `recetas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recetas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `historia_clinica_id` int(11) NOT NULL,
  `paciente_id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `fecha_emision` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_vencimiento` date DEFAULT NULL,
  `instrucciones_generales` text DEFAULT NULL,
  `activa` tinyint(1) DEFAULT 1,
  `diagnostico` text DEFAULT NULL,
  `medicamentos` text DEFAULT NULL,
  `dosis` varchar(100) DEFAULT NULL,
  `frecuencia` varchar(100) DEFAULT NULL,
  `duracion` varchar(100) DEFAULT NULL,
  `indicaciones` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `historia_clinica_id` (`historia_clinica_id`),
  KEY `doctor_id` (`doctor_id`),
  KEY `idx_recetas_paciente` (`paciente_id`),
  CONSTRAINT `recetas_ibfk_2` FOREIGN KEY (`paciente_id`) REFERENCES `pacientes` (`id`),
  CONSTRAINT `recetas_ibfk_3` FOREIGN KEY (`doctor_id`) REFERENCES `doctores` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recetas`
--

LOCK TABLES `recetas` WRITE;
/*!40000 ALTER TABLE `recetas` DISABLE KEYS */;
INSERT INTO `recetas` VALUES (2,0,1,1,'2025-10-30 20:26:04',NULL,NULL,1,'gripe','acetaminofen','1 tableta','cada 5 horas','30 dias','');
/*!40000 ALTER TABLE `recetas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rol_permisos`
--

DROP TABLE IF EXISTS `rol_permisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rol_permisos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rol_id` int(11) NOT NULL,
  `permiso_id` int(11) NOT NULL,
  `fecha_asignacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_rol_permiso` (`rol_id`,`permiso_id`),
  KEY `permiso_id` (`permiso_id`),
  CONSTRAINT `rol_permisos_ibfk_1` FOREIGN KEY (`rol_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `rol_permisos_ibfk_2` FOREIGN KEY (`permiso_id`) REFERENCES `permisos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rol_permisos`
--

LOCK TABLES `rol_permisos` WRITE;
/*!40000 ALTER TABLE `rol_permisos` DISABLE KEYS */;
INSERT INTO `rol_permisos` VALUES (8,2,10,'2025-10-31 21:12:21'),(9,2,13,'2025-10-31 21:12:21'),(10,2,11,'2025-10-31 21:12:21'),(11,2,2,'2025-10-31 21:12:21'),(12,2,7,'2025-10-31 21:12:21'),(13,2,3,'2025-10-31 21:12:21'),(14,2,1,'2025-10-31 21:12:21'),(15,2,9,'2025-10-31 21:12:21'),(16,2,14,'2025-10-31 21:12:21'),(17,2,15,'2025-10-31 21:12:21'),(30,4,6,'2025-10-31 21:12:21'),(31,4,22,'2025-10-31 21:12:21'),(32,4,26,'2025-10-31 21:12:21'),(33,4,4,'2025-10-31 21:12:21'),(34,4,24,'2025-10-31 21:12:21'),(35,4,10,'2025-10-31 21:12:21'),(36,4,13,'2025-10-31 21:12:21'),(37,4,25,'2025-10-31 21:12:21'),(38,4,16,'2025-10-31 21:12:21'),(39,4,18,'2025-10-31 21:12:21'),(40,4,5,'2025-10-31 21:12:21'),(41,4,11,'2025-10-31 21:12:21'),(42,4,2,'2025-10-31 21:12:21'),(43,4,17,'2025-10-31 21:12:21'),(44,4,23,'2025-10-31 21:12:21'),(45,4,19,'2025-10-31 21:12:21'),(46,4,7,'2025-10-31 21:12:21'),(47,4,21,'2025-10-31 21:12:21'),(48,4,3,'2025-10-31 21:12:21'),(49,4,8,'2025-10-31 21:12:21'),(50,4,1,'2025-10-31 21:12:21'),(51,4,12,'2025-10-31 21:12:21'),(52,4,20,'2025-10-31 21:12:21'),(53,4,9,'2025-10-31 21:12:21'),(54,4,14,'2025-10-31 21:12:21'),(55,4,15,'2025-10-31 21:12:21'),(61,3,6,'2025-10-31 21:20:06'),(62,3,4,'2025-10-31 21:20:06'),(63,3,5,'2025-10-31 21:20:06'),(64,3,7,'2025-10-31 21:20:06'),(65,3,3,'2025-10-31 21:20:06'),(66,3,2,'2025-10-31 21:20:06'),(67,3,1,'2025-10-31 21:20:06'),(68,3,15,'2025-10-31 21:20:06'),(69,1,19,'2025-10-31 22:41:57'),(70,1,6,'2025-10-31 22:41:57'),(71,1,4,'2025-10-31 22:41:57'),(72,1,3,'2025-10-31 22:41:57'),(73,1,2,'2025-10-31 22:41:57'),(74,1,1,'2025-10-31 22:41:57'),(75,1,8,'2025-10-31 22:41:57'),(76,1,12,'2025-10-31 22:41:57');
/*!40000 ALTER TABLE `rol_permisos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'admin','Administrador del sistema con acceso total','2025-10-23 21:39:25'),(2,'doctor','Médico que puede diagnosticar y recetar','2025-10-23 21:39:25'),(3,'secretaria','Personal administrativo que gestiona citas','2025-10-23 21:39:25'),(4,'paciente','Usuario que consulta su información médica','2025-10-23 21:39:25');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `cedula` varchar(20) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `rol_id` int(11) NOT NULL,
  `nombre_completo` varchar(150) NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `genero` enum('Masculino','Femenino','Otro') DEFAULT NULL,
  `activo` tinyint(1) DEFAULT 1,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `cedula` (`cedula`),
  KEY `idx_usuario_rol` (`rol_id`),
  CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`rol_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (3,'admin','admin@clinica.com',NULL,'scrypt:32768:8:1$gjkwwk4dRetoPgvq$f2f8b0772dfcc1ec223255c9173e494c27ea39d758a761e07a5ca3408a58fbfbbc995291545da69b00d171d1affda1d808a197e4bc3dcb6d26725c06198cbf54',1,'Administrador del Sistema',NULL,NULL,NULL,NULL,1,'2025-10-23 22:19:20'),(4,'doctor','doctor@clinica.com',NULL,'scrypt:32768:8:1$u7KvxJoOfeIJkVJl$c5900d467e93052566188b2187ff32479ef8119b97d3017e291ba049104c8ce3a9c02648fc7833557d93883e882f30687198e57edf706d146409b42f6e6112b8',2,'Dr. Juan García',NULL,NULL,NULL,NULL,1,'2025-10-23 22:19:20'),(5,'secretaria','secretaria@clinica.com',NULL,'scrypt:32768:8:1$Zm6ljdgDoSpjcJlA$a7b99ad3720cd3266fccab4b6ee6acf65e58f03c998715485f45169a7922c03d62fae4890564f9309301b9a715627268931c332cf7866e3c34e4c601504be2ca',3,'María López',NULL,NULL,NULL,NULL,1,'2025-10-23 22:19:20'),(6,'paciente','paciente@clinica.com',NULL,'scrypt:32768:8:1$EOgLHfdZYOnd7AWh$d616503e001749c009ba99630deebff2d2c15c722c35995f7a0a382effdcccd3ba7f3d350ed13ce010ae4c7cb0d528be2b5d91b85ae9e99226d25a1ee0bf9e9d',4,'Carlos Rodríguez','','','1990-05-15',NULL,1,'2025-10-23 22:19:20'),(8,'dr.Yasuo','yasuo@gmail.com',NULL,'scrypt:32768:8:1$l4iZoHxJFMNqqYuN$c5c6d97452b559d98a216f39393838290f54b13cae4660086b0bd2abf7d7368e2df9daa1ce1c8cc9da8ee36db926dfe261e433999f3f47a4dcdf0716e5109656',2,'Yasuo Linares','3208334956','Calle123','1987-12-12',NULL,1,'2025-10-31 00:54:16'),(9,'Katarina','Katarina@gmail.com',NULL,'scrypt:32768:8:1$PJyBVdwdcnleKnmc$3546418bf60c65ffdb18b6eec6bda9716433d8dabaa9c0ab9b2a634c2bd453a9bbdc3e426b866a86ac578e26803f43b6f80561e8ba96636a9bf2fca880d2a32a',3,'Katarina Colmenares','3208334958','Calle123','2000-09-24',NULL,1,'2025-10-31 01:00:50'),(10,'admin2','admin@gmail.com',NULL,'scrypt:32768:8:1$jNJ5sz1Ofh4kqOCS$d99790790b86ddafd1756488f580793a4aea3061f63018191300a8460680b569506155b028cff4c9a01a7ea7c1e91827a9505ced796efea19c1121769841a8dd',4,'Ezio Auditore','3208334959',NULL,NULL,NULL,1,'2025-10-31 01:05:26'),(11,'1016944578','Pepeelpollo@gmail.com','1016944578','',4,'Pepe el pollo','3208334941',NULL,NULL,NULL,1,'2025-10-31 22:38:22');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-31 18:12:57
