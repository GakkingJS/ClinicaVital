import os
from flask import Flask, render_template, request, redirect, url_for, session, flash, g
from flask_mysqldb import MySQL
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from functools import wraps
from datetime import datetime


# =====================================
# IMPORTAR BLUEPRINTS Y AYUDANTES
# =====================================
from utils.helpers import registrar_auditoria, generar_password_temporal
from utils.decorators import login_required, role_required, permission_required


# Importar los blueprints
from routes.admin import admin_bp
from routes.doctor import doctor_bp
from routes.paciente import paciente_bp
from routes.secretaria import secretaria_bp
from routes.auth import auth_bp 


app = Flask(__name__)
app.secret_key = 'clave_super_segura'
app.config['SESSION_PERMANENT'] = False
app.config['SESSION_TYPE'] = 'filesystem'


from config import Config
app.config.from_object(Config)
mysql = MySQL(app)


# =====================================
# CONFIGURACIÓN DE UPLOADS
# =====================================
UPLOAD_FOLDER = os.path.join(app.root_path, 'static', 'uploads', 'firmas')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 2 * 1024 * 1024  # 2MB máximo

# Crear carpeta si no existe
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


# =====================================
# CONTEXTO GLOBAL (g)
# =====================================
@app.before_request
def before_request():
    """Hace que la conexión mysql esté disponible en el objeto g"""
    g.mysql = mysql


# =====================================
# REGISTRO DE BLUEPRINTS
# =====================================
app.register_blueprint(admin_bp, url_prefix='/admin')
app.register_blueprint(doctor_bp, url_prefix='/doctor')
app.register_blueprint(paciente_bp, url_prefix='/paciente')
app.register_blueprint(secretaria_bp, url_prefix='/secretaria')
app.register_blueprint(auth_bp, url_prefix='/auth') 


# =====================================
# RUTAS PÚBLICAS
# =====================================

@app.route('/')
def index():
    """Página de inicio"""
    return render_template('index.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    """Redirige a la ruta de login en auth"""
    return redirect(url_for('auth.login'))


@app.route('/register', methods=['GET', 'POST'])
def register():
    """Redirige a la ruta de registro en auth"""
    return redirect(url_for('auth.register'))


@app.route('/logout', methods=['GET', 'POST'])
def logout():
    """Redirige a la ruta de logout en auth"""
    return redirect(url_for('auth.logout'))


# =====================================
# DASHBOARD GENERAL
# =====================================

@app.route('/dashboard')
@login_required
def dashboard():
    """Redirige al dashboard específico según el rol"""
    rol = session.get('rol')
    
    if rol == 'doctor':
        return redirect(url_for('doctor.dashboard'))
    elif rol == 'paciente':
        return redirect(url_for('paciente.dashboard'))
    elif rol == 'secretaria':
        return redirect(url_for('secretaria.dashboard'))
    elif rol == 'admin':
        return redirect(url_for('admin.dashboard'))
    else:
        flash('Rol no identificado', 'danger')
        return redirect(url_for('auth.login'))


# =====================================
# ERROR HANDLERS
# =====================================

@app.errorhandler(404)
def not_found(error):
    """Página 404"""
    return render_template('404.html'), 404


@app.errorhandler(500)
def internal_error(error):
    """Página 500"""
    try:
        g.mysql.connection.rollback()
    except Exception as e:
        app.logger.error(f"Error durante rollback en 500: {e}")
    return render_template('500.html'), 500


# =====================================
# CONTEXT PROCESSORS
# =====================================

@app.context_processor
def inject_now():
    """Inyecta datetime.now() en todos los templates"""
    return {'now': datetime.now()}


# =====================================
# INICIAR APLICACIÓN
# =====================================

if __name__ == '__main__':
    app.run(debug=True)
